
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert
} from "react-native";

import { auth, db } from "./firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

export default function App() {
  const [tipo, setTipo] = useState("doador");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  const handleCadastro = async () => {
    if (!nome || !email || !telefone || !senha) {
      Alert.alert("Erro", "Preencha todos os campos");
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert("Erro", "As senhas não coincidem");
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        senha
      );

      const user = userCredential.user;

      await setDoc(doc(db, "usuarios", user.uid), {
        nome,
        email,
        telefone,
        tipo
      });

      Alert.alert("Sucesso", "Conta criada com sucesso!");
    } catch (error) {
      Alert.alert("Erro", error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Criar conta</Text>

      <Text style={styles.subtitle}>Você é:</Text>

      <View style={styles.tipoContainer}>
        <TouchableOpacity
          style={[
            styles.tipoBtn,
            tipo === "doador" && styles.tipoSelecionado
          ]}
          onPress={() => setTipo("doador")}
        >
          <Text>Doador</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.tipoBtn,
            tipo === "receptor" && styles.tipoSelecionado
          ]}
          onPress={() => setTipo("receptor")}
        >
          <Text>Receptor</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        placeholder="Nome completo"
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        placeholder="Digite seu email"
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        placeholder="Digite seu telefone"
        style={styles.input}
        value={telefone}
        onChangeText={setTelefone}
      />

      <TextInput
        placeholder="Digite sua senha"
        style={styles.input}
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <TextInput
        placeholder="Confirme sua senha"
        style={styles.input}
        secureTextEntry
        value={confirmarSenha}
        onChangeText={setConfirmarSenha}
      />

      <TouchableOpacity style={styles.button} onPress={handleCadastro}>
        <Text style={styles.buttonText}>Cadastrar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5D7B2",
    padding: 20,
    justifyContent: "center"
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "green"
  },
  subtitle: {
    marginBottom: 10
  },
  tipoContainer: {
    flexDirection: "row",
    marginBottom: 20
  },
  tipoBtn: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
    alignItems: "center",
    marginHorizontal: 5,
    backgroundColor: "#eee"
  },
  tipoSelecionado: {
    borderColor: "green",
    backgroundColor: "#c8f7c5"
  },
  input: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 10,
    marginBottom: 10
  },
  button: {
    backgroundColor: "#D35400",
    padding: 15,
    borderRadius: 10,
    marginTop: 10
  },
  buttonText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "bold"
  }
});