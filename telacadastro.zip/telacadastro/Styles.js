
export default styles;
      <View style={styles.inputContainer}>
      
        <TextInput 
          style={styles.input_contato} 
          placeholder="Digite sua senha"
          secureTextEntry={secureMode}
          value={senha}
          onChangeText={setSenha}
        />
        <TouchableOpacity onPress={() => setSecureMode(!secureMode)}>
          <MaterialCommunityIcons 
            name={secureMode ? "eye-off-outline" : "eye-outline"} 
            size={24} 
            color="black" 
          />
        </TouchableOpacity>
      </View>
