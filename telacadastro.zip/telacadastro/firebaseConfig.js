import firebase from 'firebase';
import 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAAsXvTqm1QyiAsj49ZtWw01llxPw2KYvM",
  authDomain: "database-63136.firebaseapp.com",
  projectId: "database-63136",
  storageBucket: "database-63136.firebasestorage.app",
  messagingSenderId: "504804763659",
  appId: "1:504804763659:web:b3ddbf24a994d0d8187f0e",
  measurementId: "G-9550S2GWVE"
};

if (!firebase.apps.length) {
 firebase.initializeApp(firebaseConfig);
}
const db = firebase.firestore();
export { db };