import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
// IMPORTAÇÃO CORRETA PARA O EXPO SNACK:
import { MaterialCommunityIcons } from '@expo/vector-icons';
import styles from '../../Styles'; 

export default function T04_RedefinirSenha({ navigation }) {
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [verSenha, setVerSenha] = useState(false);

  return (
    <ScrollView style={styles.safeArea} contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>
        
        <Text style={styles.texto_bem_vindo}>Digite sua nova senha</Text>
        <Text style={[styles.subtitle, { paddingHorizontal: 20, marginTop: 10, marginBottom: 40 }]}>
          Crie uma senha forte com pelo menos 8 caracteres para proteger sua conta
        </Text>

        {/* Campo Nova Senha com ícone de olho */}
        <View style={styles.inputContainer}>
          <TextInput
            style={{ flex: 1, height: '100%' }}
            placeholder="Digite sua senha"
            secureTextEntry={!verSenha}
            value={senha}
            onChangeText={setSenha}
            placeholderTextColor="#888"
          />
          <TouchableOpacity onPress={() => setVerSenha(!verSenha)}>
            <MaterialCommunityIcons 
              name={verSenha ? "eye-off-outline" : "eye-outline"} 
              size={22} 
              color="#555" 
            />
          </TouchableOpacity>
        </View>

        {/* Campo Confirmar Senha */}
        <View style={styles.inputContainer}>
          <TextInput
            style={{ flex: 1, height: '100%' }}
            placeholder="Confirme sua senha"
            secureTextEntry={!verSenha}
            value={confirmarSenha}
            onChangeText={setConfirmarSenha}
            placeholderTextColor="#888"
          />
          <TouchableOpacity onPress={() => setVerSenha(!verSenha)}>
            <MaterialCommunityIcons 
              name={verSenha ? "eye-off-outline" : "eye-outline"} 
              size={22} 
              color="#555" 
            />
          </TouchableOpacity>
        </View>

        {/* Botão Entrar (Laranja) */}
        <TouchableOpacity 
          style={styles.botao_entrar} 
          onPress={() => {
            alert("Senha alterada com sucesso!");
            navigation.navigate('Login');
          }}
        >
          <Text style={styles.texto_botao_entrar}>Entrar</Text>
        </TouchableOpacity>

        {/* Seção de Requisitos com os Checks (v) do protótipo */}
        <View style={{ marginTop: 40, alignSelf: 'flex-start', marginLeft: '5%' }}>
          <Text style={{ color: '#555', marginBottom: 12, fontSize: 14 }}>Sua senha deve conter:</Text>
          
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <Text style={{ color: '#555', fontSize: 13, }}>Mínimo 8 caracteres  </Text>
            <MaterialCommunityIcons name="check" size={18} color="#333" />
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <Text style={{ color: '#555', fontSize: 13 }}>Pelo menos uma letra maiúscula  </Text>
            <MaterialCommunityIcons name="check" size={18} color="#333" />
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <Text style={{ color: '#555', fontSize: 13 }}>Um número ou símbolo  </Text>
            <MaterialCommunityIcons name="check" size={18} color="#333" />
          </View>
        </View>

        {/* Nota de rodapé LGPD */}
        <Text style={{ 
          fontSize: 11, 
          color: '#888', 
          textAlign: 'center', 
          marginTop: 'auto', 
          paddingBottom: 20,
          paddingHorizontal: 40 
        }}>
          Ao cadastrar, você concorda com a Política de Privacidade conforme LGPD
        </Text>

      </View>
    </ScrollView>
  );
}