import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, Alert } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import styles from './Styles';

export default function TelaContato() {
  const [senha, setSenha] = useState('');
  const [rsenha, setRSenha] = useState('');
  const [secureMode, setSecureMode] = useState(true);

  // Funções de validação em tempo real
  const temOitoCaracteres = senha.length >= 8;
  const temMaiuscula = /[A-Z]/.test(senha);
  const temNumeroOuSimbolo = /[0-9!@#$%^&*(),.?":{}|<>]/.test(senha);

  const validarSenha = () => {
    // Esse log aparece na aba "Errors/Logs" na parte de baixo do seu navegador
    console.log("Tentando validar senha..."); 

    if (!temOitoCaracteres || !temMaiuscula || !temNumeroOuSimbolo) {
      alert("Atenção: Sua senha não atende aos requisitos.");
      return;
    }

    if (senha !== rsenha) {
      alert("Erro: As senhas não são iguais.");
      return;
    }

    alert("Sucesso! Senha alterada.");
  };

  // Componente de Requisito que muda de cor se estiver ok
  const Requisito = ({ texto, validado }) => (
    <View style={styles.item_requisito}>
      <Text style={[styles.texto_item, validado && { color: '#228B22', fontWeight: 'bold' }]}>
        {texto}
      </Text>
      <MaterialCommunityIcons 
        name="check" 
        size={20} 
        color={validado ? "#228B22" : "#999"} 
      />
    </View>
  );

  return (
    <View style={styles.container_contato}>
      <View style={styles.view_texto_contato}>
        <Text style={styles.texto_contato}>Digite sua nova senha</Text>
      </View>
      
      <Text style={styles.subtitulo}>
        Crie uma senha forte para proteger sua conta
      </Text>

      <View style={styles.inputContainer}>
        <TextInput 
          style={styles.input_contato} 
          placeholder="Digite sua senha"
          secureTextEntry={secureMode}
          value={senha}
          onChangeText={setSenha}
        />
        <TouchableOpacity onPress={() => setSecureMode(!secureMode)}>
          <MaterialCommunityIcons name={secureMode ? "eye-off-outline" : "eye-outline"} size={24} color="black" />
        </TouchableOpacity>
      </View>

      <View style={styles.inputContainer}>
        <TextInput 
          style={styles.input_contato} 
          placeholder="Confirme sua senha"
          secureTextEntry={secureMode}
          value={rsenha}
          onChangeText={setRSenha}
        />
        <TouchableOpacity onPress={() => setSecureMode(!secureMode)}>
          <MaterialCommunityIcons name={secureMode ? "eye-off-outline" : "eye-outline"} size={24} color="black" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.botao} onPress={validarSenha}>
        <Text style={styles.texto_botao}>Entrar</Text>
      </TouchableOpacity>

      <View style={styles.view_requisitos}>
        <Text style={styles.texto_requisito_titulo}>Sua senha deve conter:</Text>
        
        <Requisito texto="Mínimo 8 caracteres" validado={temOitoCaracteres} />
        <Requisito texto="Pelo menos uma letra maiúscula" validado={temMaiuscula} />
        <Requisito texto="Um número ou símbolo" validado={temNumeroOuSimbolo} />
      </View>

      <Text style={styles.footer_texto}>
        Ao cadastrar, você concorda com a Política de Privacidade conforme LGPD
      </Text>
    </View>
  );
}