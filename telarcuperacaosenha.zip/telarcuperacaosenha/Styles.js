import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container_contato: {
    flex: 1,
    padding: 30,
    backgroundColor: '#FFE4B5',
    justifyContent: 'center',
    borderRadius: 40,
  },
  view_texto_contato: {
    alignItems: 'center',
    marginBottom: 10,
  },
  texto_contato: {
    color: '#228B22',
    fontWeight: 'bold',
    fontSize: 24,
    textAlign: 'center',
  },
  subtitulo: {
    textAlign: 'center',
    color: '#8B7355',
    marginBottom: 30,
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderWidth: 1.5,
    borderColor: '#000',
    borderRadius: 20,
    marginBottom: 20,
    paddingHorizontal: 15,
    height: 55,
  },
  input_contato: {
    flex: 1,
    fontSize: 16,
  },
  botao: {
    backgroundColor: '#D34800',
    width: '100%',
    height: 55,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 15,
    marginTop: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
  },
  texto_botao: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  view_requisitos: {
    marginTop: 30,
  },
  texto_requisito_titulo: {
    color: '#8B7355',
    textAlign: 'center',
    marginBottom: 15,
    fontSize: 16,
  },
  item_requisito: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  texto_item: {
    color: '#666',
    fontSize: 15,
  },
  footer_texto: {
    marginTop: 40,
    fontSize: 12,
    color: '#8B7355',
    textAlign: 'center',
  }
});

export default styles;