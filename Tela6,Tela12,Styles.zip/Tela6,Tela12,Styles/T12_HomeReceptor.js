import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StatusBar, SafeAreaView, TextInput, Image } from 'react-native';
import styles from '../../Styles';

export default function T12_HomeReceptor({ navigation }) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#006B14" />

      {/* Header com Localização Real */}
      <View style={styles.headerReceptor}>
        <View style={styles.locationContainer}>
          <Text style={styles.locationIcone}>📍</Text>
          <Text style={styles.locationText}>Fortaleza, CE</Text>
        </View>
        <TouchableOpacity activeOpacity={0.7}>
          <Text style={styles.menuIconeTexto}>≡</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.conteudo} showsVerticalScrollIndicator={false}>
        
        {/* Barra de Busca */}
        <View style={styles.searchContainer}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput 
            style={styles.searchInput}
            placeholder="Buscar alimentos..."
            placeholderTextColor="#555"
          />
        </View>

        {/* Filtros */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtersRow}>
          <TouchableOpacity style={[styles.filterBtn, styles.filterBtnActive]} activeOpacity={0.8}>
            <Text style={styles.filterTextActive}>Filtrar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterBtn} activeOpacity={0.8}>
            <Text style={styles.filterText}>Todos</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterBtn} activeOpacity={0.8}>
            <Text style={styles.filterText}>Verduras</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterBtn} activeOpacity={0.8}>
            <Text style={styles.filterText}>Prontos</Text>
          </TouchableOpacity>
        </ScrollView>

        {/* Lista de Doações (Cards Estáticos) */}
        
        {/* Card 1 */}
        <View style={styles.cardReceptor}>
          <Image 
            source={{ uri: 'https://img.freepik.com/fotos-premium/a-autentica-marmita-brasileira-mais-conhecida-como-marmitex-feita-com-comida-tradicional-do-brasil_496782-2496.jpg' }} 
            style={styles.cardImage} 
          />
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>Marmita Caseira</Text>
            <View style={styles.cardLocationRow}>
              <Text style={styles.cardDistanceIcon}>📍</Text>
              <Text style={styles.cardDistanceText}>1,2km</Text>
            </View>
            <TouchableOpacity style={styles.btnDetalhes} activeOpacity={0.8}>
              <Text style={styles.btnDetalhesText}>Detalhes</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Card 2 */}
        <View style={styles.cardReceptor}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=250&auto=format&fit=crop' }} 
            style={styles.cardImage} 
          />
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>Pães Frescos</Text>
            <View style={styles.cardLocationRow}>
              <Text style={styles.cardDistanceIcon}>📍</Text>
              <Text style={styles.cardDistanceText}>3km</Text>
            </View>
            <TouchableOpacity style={styles.btnDetalhes} activeOpacity={0.8}>
              <Text style={styles.btnDetalhesText}>Detalhes</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Card 3 */}
        <View style={styles.cardReceptor}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=250&auto=format&fit=crop' }} 
            style={styles.cardImage} 
          />
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>Cesta de HortiFruti</Text>
            <View style={styles.cardLocationRow}>
              <Text style={styles.cardDistanceIcon}>📍</Text>
              <Text style={styles.cardDistanceText}>5km</Text>
            </View>
            <TouchableOpacity style={styles.btnDetalhes} activeOpacity={0.8}>
              <Text style={styles.btnDetalhesText}>Detalhes</Text>
            </TouchableOpacity>
          </View>
        </View>

      </ScrollView>

      {/* Barra de navegação específica do Receptor */}
      <View style={styles.navBar}>
        <TouchableOpacity style={styles.navItem} activeOpacity={0.7}>
          <Text style={styles.navIconeAtivo}>🏠</Text>
          <Text style={styles.navLabelAtivo}>Início</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} activeOpacity={0.7}>
          <Text style={styles.navIcone}>🗺️</Text>
          <Text style={styles.navLabel}>Mapa</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} activeOpacity={0.7}>
          <Text style={styles.navIcone}>🛍️</Text>
          <Text style={styles.navLabel}>Pedidos</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation?.navigate('Chat')} activeOpacity={0.7}>
          <Text style={styles.navIcone}>💬</Text>
          <Text style={styles.navLabel}>Chat</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}