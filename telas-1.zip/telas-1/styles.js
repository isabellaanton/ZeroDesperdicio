import { StyleSheet } from 'react-native';
const styles = StyleSheet.create({
 container:{
 flex:1,
 justifyContent: 'center',
 alignItems: 'center',
 backgroundColor: '#FFDDAE',
 borderRadius: 40,
 },
 texto: {
 fontSize: 25,
 color: '#006B14',
 fontFamily: 'Times New Romam',
 fontWeight: 'bold',
 marginBottom: 10,
 marginLeft: 30,
 marginRight: 30 ,
 },
 
 texto2: {
 fontSize: 12,
 color: '#555555',
 fontFamily: 'Times New Romam',
 marginBottom: 20,
 marginLeft: 85,
 marginRight: 60 ,
justifyContent: 'center',
 alignItems: 'center',
 },
 texto3: {
 fontSize: '',
 color: '#006B14',
 fontWeight: 'bold',
 marginBottom: 30,
 marginLeft: 30,
 marginRight: 30 ,
 },

 imagem: {
 marginBottom: 10,
 width: 350,
 height: 230,
 resizeMode: 'contain',
 },
botao:{

 backgroundColor: '#DA4A02',
 width: 150,
 height: 35,
 alignItems: 'center',
 justifyContent: 'center',
 borderRadius: 10,
 marginBottom: 30,
},
texto_botao:{
 color:'white',
 fontSize: 15,
 fontFamily: 'Times New Romam',
},
botao2:{

backgroundColor: 'white',
borderWidth: 1 ,
borderColor:'#DA4A02',
 width: 150,
 height: 35,
 alignItems: 'center',
 justifyContent: 'center',
 borderRadius: 10,
},
texto_botao2:{
 color:'#DA4A02',
 fontSize: 15,
 fontFamily: 'Times New Romam',

},



});
export default styles;