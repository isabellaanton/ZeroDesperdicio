import { Text, View, Image, Linking, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons } from 'react-native-vector-icons';
import styles from './styles';
function TelaInfo({navigation}) {
  
 return (
   
<View style={styles.container}>
<View>
<Image style={styles.imagem} source={require('./imagem2.png')}/>
</View>

    

    <Text style={styles.texto2}>Menos desperdício. Mais pessoas alimentadas</Text>

    <Text style={styles.texto3}>
   • Cadastre uma doação em 2 minutos{"\n"}
   • Veja doações disponiveis perto de você{"\n"}
   • Combine a retirada pelo chat</Text>

    <TouchableOpacity style={styles.botao}>
      <Text style={styles.texto_botao}>Entrar</Text>
    </TouchableOpacity>

    <TouchableOpacity style={styles.botao2}>
      <Text style={styles.texto_botao2}>Criar conta</Text>
    </TouchableOpacity>

  </View>

 );
}
export default TelaInfo;