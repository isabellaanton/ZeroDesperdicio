import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
// IMPORTAÇÃO CORRETA PARA O EXPO SNACK:
import { MaterialCommunityIcons } from '@expo/vector-icons';
import styles from '../../Styles'; 

export default function T04_RedefinirSenha({ navigation }) {
  const [email, setEmail] = useState('');

  return (
    <ScrollView style={styles.safeArea} contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>
        
        {/* Título e Subtítulo idênticos ao protótipo */}
        <Text style={styles.texto_bem_vindo}>Digite seu email</Text>
        
        {/* Campo Nova Senha com ícone de olho */}
        <View style={styles.inputContainer}>
          <TextInput
            style={{ flex: 1, height: '100%' }}
            placeholder="Digite sua senha"
            value={email}
            onChangeText={setEmail}
            placeholderTextColor="#888"
          />
        </View>

        {/* Botão Entrar (Laranja) */}
        <TouchableOpacity 
          style={styles.botao_entrar} 
          onPress={() => {
            alert("Altenticando Email!");
            navigation.navigate('Login');
          }}
        >
          <Text style={styles.texto_botao_entrar}>Entrar</Text>
        </TouchableOpacity>


        {/* Nota de rodapé LGPD */}
        <Text style={{ 
          fontSize: 15, 
          color: '#888', 
          textAlign: 'center', 
          marginTop: 'auto', 
          paddingBottom: 20,
          paddingHorizontal: 40 
        }}>
          Ao cadastrar, você concorda com a Política de Privacidade conforme LGPD
        </Text>

      </View>
    </ScrollView>
  );
}