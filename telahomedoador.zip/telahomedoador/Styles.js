import { StyleSheet, Platform } from 'react-native';

const VERDE_ESCURO = '#006B14';
const LARANJA = '#DA4A02';
const FUNDO = '#FFDDAE';
const BEGE_CARD = '#FFD2AE';
const TEXTO_ESCURO = '#1A1A1A';
const TEXTO_MEDIO = '#555555';
const TEXTO_CLARO = '#888888';
const BRANCO = '#FFFFFF';

export default StyleSheet.create({
  safeArea: {
  flex: 1,
  backgroundColor: FUNDO, 
},

  // Header
  header: {
  backgroundColor: VERDE_ESCURO,
  paddingHorizontal: 20,
  paddingTop: Platform.OS === 'android' ? 16 : 8,
  paddingBottom: 30,
  paddingTop: 30,
  borderBottomLeftRadius: 40,
  borderBottomRightRadius: 40,
  height: 250,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  saudacao: {
    fontSize: 25,
    fontWeight: '700',
    color: BRANCO,
    letterSpacing: 0.2,
    paddingBottom: 25,
  },
  nomeRestaurante: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.75)',
    paddingBottom: 5,
  },
  menuIcone: {
    padding: 4,
  },
  menuIconeTexto: {
    fontSize: 35,
    color: BRANCO,
  },

  // Cards de resumo
  resumoContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  resumoCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  resumoCardDestaque: {
    backgroundColor: LARANJA,
  },
  resumoNumero: {
    fontSize: 28,
    fontWeight: '700',
    color: BRANCO,
  },
  resumoLabel: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  resumoNumeroDestaque: {
    fontSize: 28,
    fontWeight: '700',
    color: BRANCO,
  },
  resumoLabelDestaque: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.85)',
    marginTop: 2,
  },

  // Conteúdo
  conteudo: {
  flex: 1,
  backgroundColor: FUNDO,
  marginTop: -1,
},
  conteudoContainer: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 20,
    
  },

  // Botão Nova Doação
  botaoNovaDoacao: {
    backgroundColor: LARANJA,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 28,
    elevation: 4,
  },
  botaoNovaDoacaoTexto: {
    fontSize: 17,
    fontWeight: '700',
    color: BRANCO,
    letterSpacing: 0.3,
  },

  // Seção título
  secaoTitulo: {
    fontSize: 11,
    fontWeight: '700',
    color: TEXTO_CLARO,
    letterSpacing: 1.2,
    marginBottom: 12,
  },

  // Card de solicitação
  cardSolicitacao: {
    backgroundColor: BEGE_CARD,
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#DA4A02',
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  nomeOng: {
    fontSize: 15,
    fontWeight: '700',
    color: TEXTO_ESCURO,
    flex: 1,
    marginRight: 8,
  },
  descricaoSolicitacao: {
    fontSize: 13,
    color: TEXTO_MEDIO,
    marginBottom: 14,
  },

  // Badge
  badgePendente: {
    backgroundColor: '#FDEBD8',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: '#F0C49A',
  },
  badgePendenteTexto: {
    fontSize: 11,
    fontWeight: '600',
    color: '#A0511A',
  },

  // Botões do card
  botoesCard: {
    flexDirection: 'row',
    gap: 10,
  },
  botaoAceitar: {
    flex: 1,
    backgroundColor: VERDE_ESCURO,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  botaoAceitarTexto: {
    fontSize: 14,
    fontWeight: '600',
    color: BRANCO,
  },
  botaoRecusar: {
    flex: 1,
    backgroundColor: FUNDO,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: LARANJA,
  },
  botaoRecusarTexto: {
    fontSize: 14,
    fontWeight: '600',
    color: LARANJA,
  },

  // Empty state
  emptyState: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyStateTexto: {
    fontSize: 14,
    color: TEXTO_CLARO,
  },

  // Barra de navegação
  navBar: {
    flexDirection: 'row',
    backgroundColor: BRANCO,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.08)',
    paddingBottom: Platform.OS === 'ios' ? 16 : 8,
    paddingTop: 10,
    paddingHorizontal: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
  },
  navIcone: {
    fontSize: 20,
    marginBottom: 2,
    opacity: 0.5,
  },
  navIconeAtivo: {
    fontSize: 20,
    marginBottom: 2,
    color: VERDE_ESCURO,
  },
  navLabel: {
    fontSize: 10,
    color: TEXTO_CLARO,
    fontWeight: '500',
  },
  navLabelAtivo: {
    fontSize: 10,
    color: VERDE_ESCURO,
    fontWeight: '700',
  },
});