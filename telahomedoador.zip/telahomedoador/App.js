import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TelaHomeDoador from './TelaHomeDoador';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="HomeDoador"
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen name="HomeDoador" component={TelaHomeDoador} />
        {/* <Stack.Screen name="NovaDoacao" component={TelaNovaDoacaoDoador} /> */}
        {/* <Stack.Screen name="Doacoes" component={TelaDoacoes} /> */}
        {/* <Stack.Screen name="Historico" component={TelaHistorico} /> */}
        {/* <Stack.Screen name="Chat" component={TelaChat} /> */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}