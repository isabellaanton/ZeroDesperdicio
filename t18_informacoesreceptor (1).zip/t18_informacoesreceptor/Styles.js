import { StyleSheet, Platform, Dimensions } from 'react-native';

// PALETA DE CORES UNIFICADA (ZeroDesperdício)
const VERDE_ESCURO = '#006B14';
const LARANJA = '#DA4A02';
const FUNDO = '#FFDDAE';
const BEGE_CARD = '#FFD2AE';
const TEXTO_ESCURO = '#1A1A1A';
const TEXTO_MEDIO = '#555555';
const TEXTO_CLARO = '#888888';
const BRANCO = '#FFFFFF';
const PRETO = '#000000';

export default StyleSheet.create({
  // --- ESTRUTURAS GERAIS --- //
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 25,
    paddingTop: 40,
    backgroundColor: FUNDO,
  },
  safeArea: {
    flex: 1,
    backgroundColor: FUNDO,
  },
  conteudo: {
    flex: 1,
    backgroundColor: FUNDO,
  },
  conteudoContainer: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 20,
  },

  // T01_Splash - Padronizada com a Home
  containerSplash: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: FUNDO, // Mesmo fundo da Home
  },

  // Estilo de texto principal (similar ao 'saudacao' da Home)
  texto2: {
    fontSize: 18,
    color: VERDE_ESCURO,
    fontWeight: '700',
    marginHorizontal: 40,
    marginBottom: 20,
  },

  // Estilo dos tópicos (similar ao 'descricaoSolicitacao' da Home)
  texto3: {
    fontSize: 15,
    color: TEXTO_ESCURO,
    lineHeight: 24,
    marginBottom: 40,
    paddingLeft: 60,
    paddingRight: 60,
    paddingHorizontal: 30,
  },

  imagem: {
    marginBottom: 30,
    width: 300,
    height: 200,
    resizeMode: 'contain',
  },

  // Botão Entrar (Igual ao 'botaoNovaDoacao' da Home)
  botao: {
    backgroundColor: LARANJA,
    width: '80%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12, // Arredondamento padrão da Home
    marginBottom: 15,
    elevation: 4, // Sombra igual ao botão da Home
  },

  texto_botao: {
    color: BRANCO,
    fontSize: 17,
    fontWeight: '700',
  },

  // Botão Criar Conta (Igual ao 'botaoRecusar' da Home)
  botao2: {
    backgroundColor: BRANCO,
    width: '80%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: LARANJA,
  },

  texto_botao2: {
    color: LARANJA,
    fontSize: 17,
    fontWeight: '700',
  },


  // --- TEXTOS E TÍTULOS (Login/Cadastro/Redefinir) //
  title: {
    fontSize: 26,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: VERDE_ESCURO,
  },
  subtitle: {
    fontSize: 15,
    textAlign: 'center',
    color: TEXTO_MEDIO,
    marginBottom: 15,
  },
  texto_bem_vindo: {
    color: VERDE_ESCURO,
    fontWeight: 'bold',
    fontSize: 28,
    textAlign: 'center',
    marginTop: 40,
  },
  texto_acesso_conta: {
    color: TEXTO_CLARO,
    fontSize: 15,
    textAlign: 'center',
    marginTop: 10,
    paddingBottom: 50,
  },

  // --- INPUTS PADRONIZADOS ---
  input: {
    backgroundColor: BRANCO,
    borderWidth: 1.5,
    borderColor: TEXTO_MEDIO,
    borderRadius: 15,
    paddingHorizontal: 20,
    height: 55,
    width: '95%',
    alignSelf: 'center',
    marginTop: 15,
  },
  inputContainer: { // Para telas com ícone de olho
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: BRANCO,
    borderWidth: 1.5,
    borderColor: TEXTO_MEDIO,
    borderRadius: 15,
    paddingHorizontal: 15,
    height: 55,
    width: '95%',
    alignSelf: 'center',
    marginTop: 15,
  },

  // --- BOTÕES ---
  botao_entrar: { // Usado no Login e Redefinir
    backgroundColor: LARANJA,
    height: 55,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 25,
    width: '90%',
    alignSelf: 'center',
    elevation: 3,
  },
  buttonPrimary: { // Alias para o botão padrão
    backgroundColor: LARANJA,
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: BRANCO,
    fontWeight: 'bold',
    fontSize: 18,
  },
  texto_botao_entrar: {
    color: BRANCO,
    fontSize: 18,
    fontWeight: 'bold',
  },

  // --- COMPONENTES ESPECÍFICOS (Cadastro) --- //
  tipoContainer: {
    flexDirection: "row",
    marginBottom: 20,
    justifyContent: 'center'
  },
  tipoBtn: {
    flex: 1,
    padding: 10,
    borderWidth: 1.5,
    borderColor: TEXTO_CLARO,
    borderRadius: 10,
    alignItems: "center",
    marginHorizontal: 5,
    backgroundColor: BRANCO
  },
  tipoSelecionado: {
    borderColor: VERDE_ESCURO,
    backgroundColor: '#C8F7C5'
  },

  // --- COMPONENTES ESPECÍFICOS (Home Doador) ---

  // Header
  header: {
    backgroundColor: VERDE_ESCURO,
    paddingHorizontal: 20,
    paddingBottom: 14,
    flexDirection: 'column', 
    alignItems: 'center',    
    justifyContent: 'center',  
    height: 260,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'center', 
    alignItems: 'center',
    width: '95%',
  },
  saudacao: {
  fontSize: 25,
  fontWeight: '700',
  color: BRANCO,
  letterSpacing: 0.2,
  paddingBottom: 25, 
},

  nomeRestaurante: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.75)',
    paddingBottom: 5,
  },
  menuIcone: {
    padding: 4,
  },
  menuIconeTexto: {
    fontSize: 35,
    color: BRANCO,
  },

  // Cards de resumo
  resumoContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  resumoCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  resumoCardDestaque: {
    backgroundColor: LARANJA,
  },
  resumoNumero: {
    fontSize: 28,
    fontWeight: '700',
    color: TEXTO_MEDIO,
    alignItems: 'center',

  },
  resumoLabel: {
    fontSize: 13,
    color: TEXTO_MEDIO,
    marginTop: 2,
    alignItems: 'center',
  },
  resumoNumeroDestaque: {
    fontSize: 28,
    fontWeight: '700',
    color: BRANCO,
    alignItems: 'center',

  },
  resumoLabelDestaque: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.85)',
    marginTop: 2,
    alignItems: 'center',

  },

  // Conteúdo
  conteudoHomeDoador: {
  flex: 1,
  backgroundColor: FUNDO,
  marginTop: -1,
},
  conteudoContainerHomeDoador: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 20,
    
  },

  // Botão Nova Doação
  botaoNovaDoacao: {
    backgroundColor: LARANJA,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 28,
    elevation: 4,
  },
  botaoNovaDoacaoTexto: {
    fontSize: 17,
    fontWeight: '700',
    color: BRANCO,
    letterSpacing: 0.3,
  },

  // Seção título
  secaoTitulo: {
    fontSize: 11,
    fontWeight: '700',
    color: TEXTO_CLARO,
    letterSpacing: 1.2,
    marginBottom: 12,
  },

  // Card de solicitação
  cardSolicitacao: {
    backgroundColor: BEGE_CARD,
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#DA4A02',
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  nomeOng: {
    fontSize: 15,
    fontWeight: '700',
    color: TEXTO_ESCURO,
    flex: 1,
    marginRight: 8,
  },
  descricaoSolicitacao: {
    fontSize: 13,
    color: TEXTO_MEDIO,
    marginBottom: 14,
  },

  // Badge
  badgePendente: {
    backgroundColor: '#FDEBD8',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: '#F0C49A',
  },
  badgePendenteTexto: {
    fontSize: 11,
    fontWeight: '600',
    color: '#A0511A',
  },

  // Botões do card
  botoesCard: {
    flexDirection: 'row',
    gap: 10,
  },
  botaoAceitar: {
    flex: 1,
    backgroundColor: VERDE_ESCURO,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  botaoAceitarTexto: {
    fontSize: 14,
    fontWeight: '600',
    color: BRANCO,
  },
  botaoRecusar: {
    flex: 1,
    backgroundColor: FUNDO,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: LARANJA,
  },
  botaoRecusarTexto: {
    fontSize: 14,
    fontWeight: '600',
    color: LARANJA,
  },

  // Empty state
  emptyState: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyStateTexto: {
    fontSize: 14,
    color: TEXTO_CLARO,
  },

  // Barra de navegação
  navBar: {
    flexDirection: 'row',
    backgroundColor: BRANCO,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.08)',
    paddingTop: 10,
    paddingHorizontal: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
  },
  navIcone: {
    fontSize: 20,
    marginBottom: 2,
    opacity: 0.5,
  },
  navIconeAtivo: {
    fontSize: 20,
    marginBottom: 2,
    color: VERDE_ESCURO,
  },
  navLabel: {
    fontSize: 10,
    color: TEXTO_CLARO,
    fontWeight: '500',
  },
  navLabelAtivo: {
    fontSize: 10,
    color: VERDE_ESCURO,
    fontWeight: '700',
  },
backBtn: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 18,
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backBtnTexto: {
    color: BRANCO,
    fontSize: 18,
    fontWeight: '700',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitulo: {
    fontSize: 11,
    fontWeight: '700',
    color: 'rgba(255,255,255,0.75)',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarArea: {
    alignItems: 'center',
    marginBottom: 6,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  avatarEmoji: {
    fontSize: 30,
  },
 
  // Stats
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 20,
    marginTop: 5,
    marginBottom: 4,
  },
 
  // Scroll
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
 
  // Info rows dentro do card
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: TEXTO_CLARO,
  },
  infoIcone: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(0,107,20,0.10)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoIconeTexto: {
    fontSize: 16,
  },
  infoLabel: {
    fontSize: 11,
    color: TEXTO_CLARO,
    fontWeight: '600',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  infoValor: {
    fontSize: 14,
    color: TEXTO_ESCURO,
    fontWeight: '500',
    marginTop: 2,
  },
 
  // Sobre
  sobreRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
 
  // Card doação
  doacaoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  doacaoIconeBox: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: 'rgba(0,107,20,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
 
  // Badge ativa
  badgeAtiva: {
    backgroundColor: '#D4EDDA',
    borderColor: '#A8D5B5',
  },
  badgeAtivaTexto: {
    color: '#1A6E35',
  },

cardSelecionado: {
    position: 'absolute',
    bottom: 12, left: 16, right: 16,
    backgroundColor: BEGE_CARD,
    borderRadius: 18,
    padding: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(218,74,2,0.3)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
  },
  cardLabel: {
    fontSize: 10, fontWeight: '700',
    color: LARANJA, letterSpacing: 1,
    textTransform: 'uppercase', marginBottom: 4,
  },
  cardNome: {
    fontSize: 22, fontWeight: '700',
    color: TEXTO_ESCURO, marginBottom: 8, lineHeight: 26,
  },
  cardInfoRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 2,
  },
  cardInfoIcone: { 
    fontSize: 13,
  },
});