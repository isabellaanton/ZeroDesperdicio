import React from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  ScrollView, 
  SafeAreaView, 
  StatusBar, 
  Platform 
} from 'react-native';
import styles from './Styles'; 

export default function InfoReceptor({ navigation }) {
  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: '#FFDDAE' }]}>
      <StatusBar barStyle="light-content" backgroundColor="#006B14" />

      {/* Header Verde Arredondado */}
      <View style={[styles.header, { 
        height: Platform.OS === 'ios' ? 280 : 260,
        borderBottomLeftRadius: 35,
        borderBottomRightRadius: 35,
        marginTop: Platform.OS === 'android' ? -StatusBar.currentHeight : 0,
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 20 : 20,
        elevation: 5,
      }]}>
        
        <View style={[styles.headerTop, { justifyContent: 'flex-start' }]}>
          <TouchableOpacity 
            style={styles.backBtn} 
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backBtnTexto}>←</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.avatarArea}>
          <View style={styles.avatar}>
            <Text style={styles.avatarEmoji}>🏘️</Text>
          </View>
          <Text style={styles.saudacao}>ONG Vida Nova</Text>
          <Text style={styles.nomeRestaurante}>Instituição Beneficiária</Text>
        </View>

        <View style={styles.statsRow}>
          <View style={styles.resumoCard}>
            <Text style={styles.resumoNumero}>152</Text>
            <Text style={styles.resumoLabel}>recebidas</Text>
          </View>
          <View style={[styles.resumoCard, styles.resumoCardDestaque]}>
            <Text style={styles.resumoNumeroDestaque}>4.9</Text>
            <Text style={styles.resumoLabelDestaque}>avaliação</Text>
          </View>
        </View>
      </View>

      {/* Conteúdo Principal */}
      <ScrollView 
        style={styles.conteudoHomeDoador}
        contentContainerStyle={[styles.scrollContent, { paddingTop: 30 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Seção Dados de Contato */}
        <Text style={styles.secaoTitulo}>DADOS DE CONTATO</Text>
        <View style={styles.cardSolicitacao}>
          <View style={styles.infoRow}>
            <View style={styles.infoIcone}><Text style={styles.infoIconeTexto}>📍</Text></View>
            <View>
              <Text style={styles.infoLabel}>Endereço</Text>
              <Text style={styles.infoValor}>Rua das Flores, 123 - Centro</Text>
            </View>
          </View>

          <View style={[styles.infoRow, { borderBottomWidth: 0 }]}>
            <View style={styles.infoIcone}><Text style={styles.infoIconeTexto}>📞</Text></View>
            <View>
              <Text style={styles.infoLabel}>Telefone</Text>
              <Text style={styles.infoValor}>(11) 98765-4321</Text>
            </View>
          </View>
        </View>

        {/* SEÇÃO SOBRE NÓS RECOLOCADA */}
        <Text style={styles.secaoTitulo}>SOBRE A INSTITUIÇÃO</Text>
        <View style={styles.cardSolicitacao}>
          <View style={styles.sobreRow}>
             <Text style={styles.descricaoSolicitacao}>
               Atuamos há mais de 10 anos no combate à fome na região central, 
               distribuindo marmitas e cestas básicas para famílias em situação 
               de vulnerabilidade social. Nosso foco é o aproveitamento total de alimentos.
             </Text>
          </View>
        </View>

      </ScrollView>

      {/* Barra de Navegação */}
      <View style={[styles.navBar, { 
          height: Platform.OS === 'ios' ? 85 : 70, 
          paddingBottom: Platform.OS === 'ios' ? 25 : 15,
          alignItems: 'center'
      }]}>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.navIcone}>🏠</Text>
          <Text style={styles.navLabel}>Início</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Doacoes')}>
          <Text style={styles.navIcone}>📦</Text>
          <Text style={styles.navLabel}>Doações</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <Text style={styles.navIcone}>📊</Text>
          <Text style={styles.navLabel}>Histórico</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <Text style={styles.navIconeAtivo}>👤</Text>
          <Text style={styles.navLabelAtivo}>Perfil</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}