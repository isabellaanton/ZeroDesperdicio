import React from 'react';
import { SafeAreaView } from 'react-native';
import TelaInfo from './TelaInfo';

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <TelaInfo />
    </SafeAreaView>
  );
}