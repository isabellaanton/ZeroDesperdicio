import { StyleSheet } from 'react-native';

// 🎨 CORES
const VERDE_ESCURO = '#006B14';
const LARANJA = '#DA4A02';
const FUNDO = '#FFDDAE';
const BEGE_CARD = '#FFD2AE';
const TEXTO_ESCURO = '#1A1A1A';
const TEXTO_CLARO = '#888888';
const BRANCO = '#FFFFFF';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: FUNDO,
  },

  header: {
    backgroundColor: VERDE_ESCURO,
    height: 90,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },

  titulo: {
    color: BRANCO,
    fontSize: 18,
    fontWeight: 'bold',
  },

  card: {
    margin: 20,
    padding: 15,
    backgroundColor: BEGE_CARD,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: LARANJA,
  },

  label: {
    color: TEXTO_CLARO,
  },

  nome: {
    fontSize: 22,
    fontWeight: 'bold',
    color: TEXTO_ESCURO,
    marginBottom: 10,
  },

  subtitulo: {
    marginTop: 10,
    marginBottom: 5,
    fontWeight: 'bold',
    color: TEXTO_ESCURO,
  },

  linha: {
    flexDirection: 'row',
    gap: 10,
  },

  inputPequeno: {
    borderWidth: 2,
    borderColor: LARANJA,
    borderRadius: 10,
    padding: 10,
    width: 80,
    textAlign: 'center',
    color: TEXTO_ESCURO,
  },

  unidades: {
    borderWidth: 2,
    borderColor: LARANJA,
    borderRadius: 10,
    padding: 10,
    justifyContent: 'center',
  },

  inputGrande: {
    borderWidth: 2,
    borderColor: LARANJA,
    borderRadius: 10,
    padding: 10,
    color: TEXTO_ESCURO,
  },

  botao: {
    backgroundColor: LARANJA,
    marginTop: 15,
    padding: 12,
    borderRadius: 20,
    alignItems: 'center',
  },

  textoBotao: {
    color: BRANCO,
    fontWeight: 'bold',
  },
});

export default styles;