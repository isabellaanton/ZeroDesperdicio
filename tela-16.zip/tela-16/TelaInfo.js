import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import styles from './styles';

// 🎨 CORES
const VERDE_ESCURO = '#006B14';
const LARANJA = '#DA4A02';
const TEXTO_MEDIO = '#555555';
const TEXTO_CLARO = '#888888';
const BRANCO = '#FFFFFF';

export default function TelaInfo() {
  const [quantidade, setQuantidade] = useState('10');
  const [observacao, setObservacao] = useState('');

  return (
    <View style={styles.container}>

      {/* HEADER */}
      <View style={styles.header}>
        <MaterialCommunityIcons name="arrow-left" size={24} color={BRANCO} />
        <Text style={styles.titulo}>Confirmar Solicitação</Text>
        <MaterialCommunityIcons name="menu" size={24} color={BRANCO} />
      </View>

      {/* CARD */}
      <View style={styles.card}>
        <Text style={styles.label}>Selecionado</Text>
        <Text style={styles.nome}>Marmita Caseira</Text>

        <Text style={styles.subtitulo}>Quantidade</Text>

        <View style={styles.linha}>
          <TextInput
            style={styles.inputPequeno}
            value={quantidade}
            onChangeText={setQuantidade}
            keyboardType="numeric"
          />

          <View style={styles.unidades}>
            <Text style={{ color: TEXTO_MEDIO }}>unidades</Text>
          </View>
        </View>

        <Text style={styles.subtitulo}>Observação</Text>

        <TextInput
          style={styles.inputGrande}
          placeholder="Ex: Sou alérgico"
          placeholderTextColor={TEXTO_CLARO}
          value={observacao}
          onChangeText={setObservacao}
        />

        <TouchableOpacity style={styles.botao}>
          <Text style={styles.textoBotao}>Solicitar</Text>
        </TouchableOpacity>
      </View>

    </View>
  );
}