import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from '../../Styles'; // Ajuste o caminho se necessário

const FAQItem = ({ pergunta, resposta }) => {
  const [expandido, setExpandido] = useState(false);

  return (
    <TouchableOpacity 
      style={[styles.cardSolicitacao, { marginBottom: 15, borderColor: '#006B14' }]} 
      onPress={() => setExpandido(!expandido)}
      activeOpacity={0.7}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={[styles.nomeOng, { color: '#006B14', fontSize: 16 }]}>{pergunta}</Text>
        <Ionicons 
          name={expandido ? "chevron-up" : "chevron-down"} 
          size={20} 
          color="#DA4A02" 
        />
      </View>
      {expandido && (
        <View style={{ marginTop: 10, borderTopWidth: 0.5, borderTopColor: '#DA4A02', paddingTop: 10 }}>
          <Text style={styles.descricaoSolicitacao}>{resposta}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

export default function T21_AjudaSuporte({ navigation }) {
  const faqs = [
    {
      pergunta: "Como faço uma doação?",
      resposta: "Clique no botão 'Nova Doação' na sua tela inicial, preencha os dados do alimento e aguarde um receptor aceitar."
    },
    {
      pergunta: "Quais alimentos são aceitos?",
      resposta: "Alimentos dentro do prazo de validade e em boas condições de higiene. Evite alimentos prontos que estragam muito rápido."
    },
    {
      pergunta: "Como entro em contato com o receptor?",
      resposta: "Após o receptor aceitar sua doação, um chat ou botão de contato será liberado nos detalhes da doação."
    },
    {
      pergunta: "A plataforma é segura?",
      resposta: "Sim! Utilizamos um sistema de avaliações (estrelas) para que a comunidade mantenha a confiança mútua."
    }
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header seguindo o padrão da T06/T19 */}
      <View style={[styles.header_cadastro, { height: 110 }]}>
        <TouchableOpacity 
          style={{ marginTop: 15 }} 
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" size={28} color="white" />
        </TouchableOpacity>
        
        <View style={styles.headerTituloCentralizado}>
          <Text style={styles.tituloCadastro}>Ajuda e Suporte</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.conteudoContainer}>
        <Text style={[styles.secaoTitulo, { marginTop: 10, marginBottom: 20 }]}>PERGUNTAS FREQUENTES</Text>
        
        {faqs.map((item, index) => (
          <FAQItem key={index} pergunta={item.pergunta} resposta={item.resposta} />
        ))}
        {/* Seção de Contatos Estática */}
<View style={{ marginTop: 30, paddingBottom: 40 }}>
  <Text style={[styles.secaoTitulo, { textAlign: 'center' }]}>CANAIS DE CONTATO</Text>
  
  <View style={[styles.cardSolicitacao, { borderColor: '#DA4A02', alignItems: 'center' }]}>
    <Text style={[styles.nomeOng, { color: '#006B14', marginBottom: 5 }]}>Suporte Zero Desperdício</Text>
    <Text style={styles.descricaoSolicitacao}>E-mail: ajuda@zerodesperdicio.com.br</Text>
    <Text style={styles.descricaoSolicitacao}>Instagram: @zerodesperdicio</Text>
    <Text style={[styles.descricaoSolicitacao, { fontSize: 11, marginTop: 10, fontStyle: 'italic' }]}>
      Atendimento de Seg. a Sex. das 08h às 18h.
    </Text>
  </View>
</View>
      </ScrollView>
    </SafeAreaView>
  );
}