import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StatusBar, SafeAreaView, Image } from 'react-native';
import styles from '../../Styles';

export default function T19_HistoricoReceptor({ navigation }) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#006B14" />

      {/* Header com Botão de Voltar */}
      <View style={styles.headerHistorico}>
        <View style={styles.headerTituloContainer}>
          <TouchableOpacity onPress={() => navigation?.goBack()} activeOpacity={0.7}>
            <Text style={styles.backIcon}>←</Text>
          </TouchableOpacity>
          <Text style={styles.tituloHistorico}>Histórico</Text>
        </View>
        <TouchableOpacity activeOpacity={0.7}>
          <Text style={styles.menuIconeTexto}>≡</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.conteudo} showsVerticalScrollIndicator={false}>
        
        {/* Card de Resumo de Estatísticas */}
        <View style={styles.cardResumoHistorico}>
          <View style={styles.resumoHistoricoItem}>
            <Text style={styles.resumoHistoricoValor}>23</Text>
            <Text style={styles.resumoHistoricoLabel}>recebidas</Text>
          </View>
          <View style={styles.resumoHistoricoItem}>
            <Text style={styles.resumoHistoricoValor}>4.8</Text>
            <Text style={styles.resumoHistoricoLabel}>avaliação</Text>
          </View>
          <View style={styles.resumoHistoricoItem}>
            <Text style={styles.resumoHistoricoValor}>52kg</Text>
            <Text style={styles.resumoHistoricoLabel}>recebidos</Text>
          </View>
        </View>

        {/* Lista de Doações Concluídas (Cards Estáticos) */}
        
        {/* Card 1 */}
        <View style={styles.cardHistorico}>
          <Image 
            source={{ uri: 'https://img.freepik.com/fotos-premium/a-autentica-marmita-brasileira-mais-conhecida-como-marmitex-feita-com-comida-tradicional-do-brasil_496782-2496.jpg' }} 
            style={styles.cardImage} 
          />
          <View style={styles.cardContentHistorico}>
            <Text style={styles.cardTitle}>Marmita Caseira</Text>
            <View style={styles.btnConcluido}>
              <Text style={styles.btnConcluidoText}>Concluído</Text>
            </View>
          </View>
        </View>

        {/* Card 2 */}
        <View style={styles.cardHistorico}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?q=80&w=250&auto=format&fit=crop' }} 
            style={styles.cardImage} 
          />
          <View style={styles.cardContentHistorico}>
            <Text style={styles.cardTitle}>Cesta de HortiFruti</Text>
            <View style={styles.btnConcluido}>
              <Text style={styles.btnConcluidoText}>Concluído</Text>
            </View>
          </View>
        </View>

      </ScrollView>

      {/* Barra de navegação */}
      <View style={styles.navBar}>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation?.navigate('HomeReceptor')} activeOpacity={0.7}>
          <Text style={styles.navIcone}>🏠</Text>
          <Text style={styles.navLabel}>Início</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} activeOpacity={0.7}>
          <Text style={styles.navIcone}>🗺️</Text>
          <Text style={styles.navLabel}>Mapa</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} activeOpacity={0.7}>
          <Text style={styles.navIcone}>🛍️</Text>
          <Text style={styles.navLabel}>Pedidos</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation?.navigate('Chat')} activeOpacity={0.7}>
          <Text style={styles.navIcone}>💬</Text>
          <Text style={styles.navLabel}>Chat</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}