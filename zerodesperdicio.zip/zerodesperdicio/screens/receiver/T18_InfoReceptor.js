import React from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  SafeAreaView, StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import FooterReceptor from './FooterReceptor';
import ResumoPerfil from '../../ResumoPerfil';

const RECEPTOR = {
  nome: 'Maria de Lourdes',
  tipo: 'Receptor Individual',
  membro_desde: 'mar/2023',
  stats: { recebidas: 63, avaliacao: '4.3' },
  endereco: 'Bairro de Fátima, Fortaleza - CE',
  telefone: '(85) 9 9988-7766',
  email: 'maria.lourdes@email.com',
  sobre: 'Faço parte de uma rede de apoio comunitário que ajuda 20 famílias no bairro. Busco doações para complementar as refeições dessas pessoas.',
};

const InfoRow = ({ icone, label, valor, ultimo, styles, theme, isDarkMode }) => (
  <View style={[styles.infoRow, ultimo && { borderBottomWidth: 0, paddingBottom: 0 }]}>
    <View style={[styles.infoIcone, { backgroundColor: isDarkMode ? 'rgba(255,255,255,0.1)' : '#E3F2FD' }]}>
      <Ionicons name={icone} size={18} color={theme.primary} />
    </View>
    <View style={{ flex: 1 }}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValor}>{valor}</Text>
    </View>
  </View>
);

const PassoRetirada = ({ numero, texto, styles, theme }) => (
  <View style={[styles.infoRow, { alignItems: 'flex-start' }]}>
    <View style={[styles.infoIcone, { backgroundColor: theme.secondary }]}>
      <Text style={{ color: '#fff', fontWeight: 'bold' }}>{numero}</Text>
    </View>
    <View style={{ flex: 1 }}>
      <Text style={[styles.infoValor, { lineHeight: 22 }]}>{texto}</Text>
    </View>
  </View>
);

export default function T18_InfoReceptor({ navigation }) {
  const { theme, isDarkMode } = useTheme();
  const styles = getGlobalStyles(theme);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle={isDarkMode ? "light-content" : "dark-content"} backgroundColor={theme.headerBackground} />

      <View style={[styles.headerTop, { backgroundColor: theme.headerBackground, height: 60, paddingHorizontal: 15 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={theme.headerTextInverse} />
        </TouchableOpacity>

        <Text style={{ color: theme.headerTextInverse, fontSize: 18, fontWeight: 'bold' }}>
          Detalhes do Receptor
        </Text>

        <TouchableOpacity>
          <Ionicons name="share-social-outline" size={24} color={theme.headerTextInverse} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.conteudo}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <ResumoPerfil
          emoji="🏘️"
          nome={RECEPTOR.nome}
          subtitulo={`${RECEPTOR.tipo} desde ${RECEPTOR.membro_desde}`}
          stats={[
            { valor: RECEPTOR.stats.recebidas, label: 'Recebidas' },
            { valor: '4,3⭐', label: 'Avaliação' },
            { valor: '180kg', label: 'Alimentos' },
          ]}
        />

        <Text style={styles.secaoTitulo}>Informações Pessoais</Text>

        <View style={styles.cardSolicitacao}>
          <InfoRow
            icone="location-outline"
            label="Localização"
            valor={RECEPTOR.endereco}
            styles={styles}
            theme={theme}
            isDarkMode={isDarkMode}
          />

          <InfoRow
            icone="call-outline"
            label="Telefone / WhatsApp"
            valor={RECEPTOR.telefone}
            styles={styles}
            theme={theme}
            isDarkMode={isDarkMode}
          />

          <InfoRow
            icone="mail-outline"
            label="E-mail de Contato"
            valor={RECEPTOR.email}
            ultimo
            styles={styles}
            theme={theme}
            isDarkMode={isDarkMode}
          />
        </View>

        <Text style={styles.secaoTitulo}>Sobre o Receptor</Text>

        <View style={styles.cardSolicitacao}>
          <Text style={[styles.descricaoSolicitacao, { color: theme.textPrimary, lineHeight: 22 }]}>
            {RECEPTOR.sobre}
          </Text>
        </View>

        <Text style={styles.secaoTitulo}>Como funciona a retirada segura</Text>

        <View style={styles.cardSolicitacao}>
          <PassoRetirada
            numero="1"
            texto="Solicite uma doação disponível e aguarde a resposta do doador."
            styles={styles}
            theme={theme}
          />

          <PassoRetirada
            numero="2"
            texto="Acompanhe o status do pedido na tela Minhas Solicitações."
            styles={styles}
            theme={theme}
          />

          <PassoRetirada
            numero="3"
            texto="Quando o pedido estiver Aceito, confira o local, horário e quantidade combinados."
            styles={styles}
            theme={theme}
          />

          <PassoRetirada
            numero="4"
            texto="Na retirada, verifique se o alimento está bem embalado e dentro do prazo de validade."
            styles={styles}
            theme={theme}
          />

          <PassoRetirada
            numero="5"
            texto="Finalize a retirada com responsabilidade e evite atrasos para não prejudicar o doador."
            styles={styles}
            theme={theme}
          />
        </View>
      </ScrollView>

      <FooterReceptor navigation={navigation} abaAtual="Info" />
    </SafeAreaView>
  );
}