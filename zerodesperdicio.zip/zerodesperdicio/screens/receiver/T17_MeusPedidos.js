import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, SafeAreaView, StatusBar, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { collection, onSnapshot } from '@firebase/firestore';
import { db } from '../../firebase';
import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import FooterReceptor from './FooterReceptor';

export default function T17_MeusPedidos({ navigation }) {
  const [abaAtiva, setAbaAtiva] = useState('Todos');
  const [pedidos, setPedidos] = useState([]);

  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  useEffect(() => {
    const cancelar = onSnapshot(collection(db, 'pedidos'), (resultado) => {
      const lista = [];

      resultado.forEach((doc) => {
        lista.push({
          id: doc.id,
          ...doc.data()
        });
      });

      setPedidos(lista);
    });

    return () => cancelar();
  }, []);

  const pedidosFiltrados = pedidos.filter((item) => {
    if (abaAtiva === 'Todos') return true;
    return item.status === abaAtiva;
  });

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor={theme.headerBackground} />

      <View style={[styles.header, { height: 70, justifyContent: 'center' }]}>
        <Text style={[styles.headerTitulo, { fontSize: 20, textAlign: 'center' }]}>
          Minhas Solicitações
        </Text>
      </View>

      <View style={styles.filtrosContainer}>
        {['Todos', 'Pendente', 'Aceito'].map((aba) => (
          <TouchableOpacity
            key={aba}
            style={[
              styles.filtroBotao,
              abaAtiva === aba && { backgroundColor: theme.secondary, borderColor: theme.secondary }
            ]}
            onPress={() => setAbaAtiva(aba)}
          >
            <Text style={[styles.filtroTexto, abaAtiva === aba && styles.filtroTextoAtivo]}>
              {aba}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.conteudo} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}>
        {pedidosFiltrados.map((item) => {
          const isAceito = item.status === 'Aceito';

          return (
            <TouchableOpacity key={item.id} style={styles.cardHistorico} activeOpacity={0.9}>
              <Image
                source={{ uri: 'https://img.freepik.com/fotos-premium/a-autentica-marmita-brasileira-mais-conhecida-como-marmitex-feita-com-comida-tradicional-do-brasil_496782-2496.jpg' }}
                style={styles.cardImage}
              />

              <View style={styles.cardContentHistorico}>
                <Text style={styles.cardTitle}>Pedido de doação</Text>
                <Text style={styles.textoCard}>ID Doação: {item.idDoacao}</Text>
                <Text style={styles.textoCard}>Quantidade: {item.quantidade}</Text>

                {item.observacao !== '' && (
                  <Text style={styles.textoCard}>Obs: {item.observacao}</Text>
                )}

                <View
                  style={[
                    styles.badgePendente,
                    isAceito && {
                      backgroundColor: '#D4EDDA',
                      borderColor: '#A8D5B5'
                    }
                  ]}
                >
                  <Text
                    style={[
                      styles.badgePendenteTexto,
                      isAceito && { color: '#1A6E35' }
                    ]}
                  >
                    {item.status}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <FooterReceptor navigation={navigation} abaAtual="Pedidos" />
    </SafeAreaView>
  );
}