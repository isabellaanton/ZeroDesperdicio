import 'react-native-gesture-handler'; // Sempre na linha 1
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Importação das 5 Telas Criadas
import T01_Splash from './screens/common/T01_Splash';
import T02_Login from './screens/common/T02_Login';
import T03_Cadastro from './screens/common/T03_Cadastro';
import T04_RedefinirSenha from './screens/common/T04_RedefinirSenha';
import T05_HomeDoador from './screens/donor/T05_HomeDoador';
import T13_FiltrarDoacoes from './screens/receiver/T13_FiltrarDoacoes';
import T14_DetalheDoacaoReceptor from './screens/receiver/T14_DetalheDoacaoReceptor';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        initialRouteName="FiltrarDoacoes" 
        screenOptions={{ headerShown: false }}
      >
        {/* Fluxo de Autenticação */}
        <Stack.Screen name="Inicio" component={T01_Splash} />
        <Stack.Screen name="Login" component={T02_Login} />
        <Stack.Screen name="Cadastro" component={T03_Cadastro} />
        <Stack.Screen name="RedefinirSenha" component={T04_RedefinirSenha} />
        
        {/* Fluxo do Doador */}
        <Stack.Screen name="HomeDoador" component={T05_HomeDoador} />
        {/* Fluxo do receptor */}
        <Stack.Screen name="FiltrarDoacoes" component={T13_FiltrarDoacoes} />
        <Stack.Screen name="DetalheDoacaoReceptor" component={T14_DetalheDoacaoReceptor} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}