import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from '../../Styles';
import { MaterialCommunityIcons } from '@expo/vector-icons';

function TelaDetalhes({ navigation, route }) {

  const categoria = route.params?.categoria;
  const distancia = route.params?.distancia;
  const disponibilidade = route.params?.disponibilidade;
  const ordem = route.params?.ordem;

  return (
    <View style={styles.container}>

      <View style={styles.container_icone_voltar_contato}>

        <TouchableOpacity onPress={() => navigation.navigate('FiltrarDoacoes')}>
          <MaterialCommunityIcons
            name='keyboard-backspace'
            size={25}
            color='black'
          />
        </TouchableOpacity>

        <Text style={styles.titulo}>
          Detalhes da doação
        </Text>

      </View>

      <Image
        source={{ uri: '' }}
        style={styles.imagem}
      />

      <Text style={styles.nome}>
        Marmita Caseira
      </Text>

      <Text style={styles.disponivel}>
        Disponível
      </Text>

      <View style={styles.card}>

        <Text style={styles.textoCard}>
          Tipo: Pronto para consumo
        </Text>

        <Text style={styles.textoCard}>
          Quantidade: 10 unidades
        </Text>

        <Text style={styles.textoCard}>
          Disponível até: Hoje, 20:00
        </Text>

        <Text style={styles.textoCard}>
          Distância: 1,2 km
        </Text>

      </View>

      <View style={styles.card}>

        <Text style={styles.label}>
          Filtros Aplicados
        </Text>

        <Text style={styles.textoCard}>
          Categoria: {categoria}
        </Text>

        <Text style={styles.textoCard}>
          Distância Máxima: {distancia}
        </Text>

        <Text style={styles.textoCard}>
          Disponibilidade: {disponibilidade}
        </Text>

        <Text style={styles.textoCard}>
          Ordenar por: {ordem}
        </Text>

      </View>

      <TouchableOpacity style={styles.botao}>
        <Text style={styles.texto_botao}>
          Ver no Mapa
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.botao}>
        <Text style={styles.texto_botao}>
          Solicitar
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.botao}>
        <Text style={styles.texto_botao}>
          Entrar em Contato
        </Text>
      </TouchableOpacity>

    </View>
  );
}

export default TelaDetalhes;