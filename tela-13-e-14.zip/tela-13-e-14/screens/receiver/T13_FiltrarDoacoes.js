import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import styles from '../../Styles';
import { MaterialCommunityIcons } from '@expo/vector-icons';

function TelaFiltro({ navigation }) {

  const [categoria, setCategoria] = useState('');
  const [distancia, setDistancia] = useState('');
  const [disponibilidade, setDisponibilidade] = useState('');
  const [ordem, setOrdem] = useState('Mais próximo');

  function aplicarFiltro() {
    navigation.navigate('DetalheDoacaoReceptor', {
      categoria: categoria,
      distancia: distancia,
      disponibilidade: disponibilidade,
      ordem: ordem
    });
  }

  return (
    <View style={styles.container}>

      <View style={styles.container_icone_voltar_contato}>

        <TouchableOpacity onPress={() => navigation.goBack()}>
          <MaterialCommunityIcons
            name='keyboard-backspace'
            size={25}
            color='black'
          />
        </TouchableOpacity>

        <Text style={styles.titulo}>
          Filtrar doações
        </Text>

      </View>

      <Text style={styles.label}>Categoria</Text>

      <View style={styles.linha}>

        <TouchableOpacity onPress={() => setCategoria('Todos')}>
          <Text style={categoria === 'Todos' ? styles.tagSelecionada : styles.tag}>
            Todos
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setCategoria('Perecíveis')}>
          <Text style={categoria === 'Perecíveis' ? styles.tagSelecionada : styles.tag}>
            Perecíveis
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setCategoria('Grãos')}>
          <Text style={categoria === 'Grãos' ? styles.tagSelecionada : styles.tag}>
            Grãos
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setCategoria('Prontos')}>
          <Text style={categoria === 'Prontos' ? styles.tagSelecionada : styles.tag}>
            Prontos
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setCategoria('Hortifruti')}>
          <Text style={categoria === 'Hortifruti' ? styles.tagSelecionada : styles.tag}>
            Hortifruti
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setCategoria('Verduras')}>
          <Text style={categoria === 'Verduras' ? styles.tagSelecionada : styles.tag}>
            Verduras
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.label}>Distância Máxima</Text>

      <TextInput
        placeholder="Digite a distância..."
        style={styles.label_input}
        keyboardType='numeric'
        value={distancia}
        onChangeText={setDistancia}
      />

      <Text style={styles.label}>Disponibilidade</Text>

      <View style={styles.linha}>

        <TouchableOpacity onPress={() => setDisponibilidade('Agora')}>
          <Text style={disponibilidade === 'Agora' ? styles.tagSelecionada : styles.tag}>
            Agora
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setDisponibilidade('Hoje')}>
          <Text style={disponibilidade === 'Hoje' ? styles.tagSelecionada : styles.tag}>
            Hoje
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setDisponibilidade('Esta semana')}>
          <Text style={disponibilidade === 'Esta semana' ? styles.tagSelecionada : styles.tag}>
            Esta semana
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.label}>Ordenar por</Text>

      <TextInput
        placeholder="Mais próximo"
        style={styles.label_input}
        value={ordem}
        onChangeText={setOrdem}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={aplicarFiltro}
      >
        <Text style={styles.texto_botao}>
          Aplicar
        </Text>
      </TouchableOpacity>

    </View>
  );
}

export default TelaFiltro;