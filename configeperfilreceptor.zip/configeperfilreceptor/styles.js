import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E7C79E',
  },

  header: {
    backgroundColor: '#0B6B1B',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    alignItems: 'center',
    paddingVertical: 20,
  },

  menuIcon: {
    position: 'absolute',
    right: 20,
    top: 20,
  },

  avatar: {
    width: 140,
    height: 140,
    borderRadius: 70,
    marginTop: 10,
  },

  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 10,
  },

  subtitle: {
    color: '#dcdcdc',
    marginTop: 4,
  },

  statsContainer: {
    flexDirection: 'row',
    marginTop: 15,
  },

  stat: {
    alignItems: 'center',
    marginHorizontal: 20,
  },

  statNumber: {
    color: '#fff',
    fontWeight: 'bold',
  },

  statLabel: {
    color: '#fff',
    fontSize: 12,
  },

  menu: {
    marginTop: 20,
    paddingHorizontal: 20,
  },

  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#999',
  },

  menuText: {
    marginLeft: 15,
    fontSize: 16,
  },

  deleteText: {
    textAlign: 'center',
    color: 'red',
    marginTop: 10,
  },

  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#E7C79E',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#999',
    marginTop: 'auto',
  },

  navItem: {
    alignItems: 'center',
  },

  navText: {
    fontSize: 12,
  },
});

export default styles;