import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StatusBar
} from 'react-native';

import { Ionicons, Feather, MaterialIcons } from '@expo/vector-icons';
import styles from './styles';
export default function App() {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0B6B1B" />

      <View style={styles.header}>
        <TouchableOpacity style={styles.menuIcon}>
          <Feather name="menu" size={24} color="#000" />
        </TouchableOpacity>

        <Image
          source={{  }}
          style={styles.avatar}
        />
        <Text style={styles.name}>Maria de Lourdes</Text>
        <Text style={styles.subtitle}>Receptor - Fortaleza, CE</Text>

        <View style={styles.statsContainer}>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>63</Text>
            <Text style={styles.statLabel}>Recebidas</Text>
          </View>

          <View style={styles.stat}>
            <Text style={styles.statNumber}>4,3</Text>
            <Text style={styles.statLabel}>Avaliações</Text>
          </View>
        </View>
      </View>
      <View style={styles.menu}>
        <MenuItem icon={<Feather name="user" size={22} />} text="Editar Perfil" />
        <MenuItem icon={<Feather name="key" size={22} />} text="Alterar Senha" />
        <MenuItem icon={<Feather name="moon" size={22} />} text="Modo Escuro" />
        <MenuItem icon={<Ionicons name="notifications-outline" size={22} />} text="Notificações" />
        <MenuItem icon={<MaterialIcons name="logout" size={22} />} text="Sair da Conta" />

        <Text style={styles.deleteText}>Excluir Conta</Text>
      </View>
      <View style={styles.bottomNav}>
      </View>
    </View>
  );
}
const MenuItem = ({ icon, text }) => (
  <TouchableOpacity style={styles.menuItem}>
    {icon}
    <Text style={styles.menuText}>{text}</Text>
  </TouchableOpacity>
);

const NavItem = ({ icon, label }) => (
  <TouchableOpacity style={styles.navItem}>
    <Ionicons name={icon} size={22} color="#333" />
    <Text style={styles.navText}>{label}</Text>
  </TouchableOpacity>
);