import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Image,
  ActivityIndicator
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { collection, query, where, onSnapshot } from '@firebase/firestore';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import FooterReceptor from './FooterReceptor';
import { auth, db } from '../../config/firebaseConfig';

export default function T17_MeusPedidos({ navigation }) {
  const [abaAtiva, setAbaAtiva] = useState('Todos');
  const [pedidos, setPedidos] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  useEffect(() => {
    const user = auth.currentUser;

    if (!user) {
      setCarregando(false);
      return;
    }

    const q = query(
      collection(db, 'pedidos'),
      where('idReceptor', '==', user.uid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const lista = [];

        snapshot.forEach((doc) => {
          lista.push({
            id: doc.id,
            ...doc.data()
          });
        });

        setPedidos(lista);
        setCarregando(false);
      },
      (error) => {
        console.log('Erro ao buscar pedidos:', error);
        setCarregando(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const pedidosFiltrados = pedidos.filter((item) => {
    if (abaAtiva === 'Todos') return true;
    return item.status === abaAtiva;
  });

  const formatarData = (dataCriacao) => {
    if (!dataCriacao || !dataCriacao.toDate) {
      return 'Data não informada';
    }

    return dataCriacao.toDate().toLocaleDateString('pt-BR');
  };

  const pegarCoresStatus = (status) => {
    if (status === 'Aceito' || status === 'Concluído') {
      return {
        fundo: '#E8F5E9',
        texto: '#006B14',
        borda: '#006B14'
      };
    }

    return {
      fundo: '#FFF3E0',
      texto: '#DA4A02',
      borda: '#DA4A02'
    };
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor={theme.headerBackground} />

      <View style={[styles.header, { height: 70, justifyContent: 'center' }]}>
        <Text style={[styles.headerTitulo, { fontSize: 20, textAlign: 'center' }]}>
          Minhas Solicitações
        </Text>
      </View>

      <View style={styles.filtrosContainer}>
        {['Todos', 'Pendente', 'Aceito', 'Concluído'].map((aba) => (
          <TouchableOpacity
            key={aba}
            style={[
              styles.filtroBotao,
              abaAtiva === aba && {
                backgroundColor: theme.secondary,
                borderColor: theme.secondary
              }
            ]}
            onPress={() => setAbaAtiva(aba)}
          >
            <Text style={[styles.filtroTexto, abaAtiva === aba && styles.filtroTextoAtivo]}>
              {aba}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {carregando ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={theme.secondary} />
        </View>
      ) : (
        <ScrollView
          style={styles.conteudo}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
        >
          {pedidosFiltrados.length === 0 ? (
            <View style={{ alignItems: 'center', marginTop: 40 }}>
              <Ionicons name="document-text-outline" size={50} color={theme.textMuted} />
              <Text style={{ color: theme.textMuted, marginTop: 10 }}>
                Nenhum pedido encontrado.
              </Text>
            </View>
          ) : (
            pedidosFiltrados.map((item) => {
              const cores = pegarCoresStatus(item.status);

              return (
                <TouchableOpacity
                  key={item.id}
                  style={styles.cardHistorico}
                  activeOpacity={0.9}
                >
                  <Image
                    source={{
                      uri:
                        item.imgDoacao ||
                        item.imagem ||
                        'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=300'
                    }}
                    style={styles.cardImage}
                  />

                  <View style={styles.cardContentHistorico}>
                    <Text style={styles.cardTitle}>
                      {item.tituloDoacao || 'Doação'}
                    </Text>

                    <Text style={styles.textoCard}>
                      {item.nomeDoador || 'Doador não informado'}
                    </Text>

                    <Text style={{ fontSize: 12, color: theme.textMuted, marginBottom: 8 }}>
                      Quantidade: {item.quantidadePedida || 1}
                    </Text>

                    <Text style={{ fontSize: 12, color: theme.textMuted, marginBottom: 8 }}>
                      {formatarData(item.dataCriacao)}
                    </Text>

                    <View
                      style={[
                        styles.badgePendente,
                        {
                          backgroundColor: cores.fundo,
                          borderColor: cores.borda,
                          borderWidth: 1
                        }
                      ]}
                    >
                      <Text
                        style={[
                          styles.badgePendenteTexto,
                          {
                            color: cores.texto,
                            fontWeight: 'bold'
                          }
                        ]}
                      >
                        {item.status || 'Pendente'}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })
          )}
        </ScrollView>
      )}

      <FooterReceptor navigation={navigation} abaAtual="Pedidos" />
    </SafeAreaView>
  );
}