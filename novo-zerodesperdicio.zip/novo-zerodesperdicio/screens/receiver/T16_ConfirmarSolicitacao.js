import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  TextInput,
  Alert,
  ActivityIndicator
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { collection, addDoc, serverTimestamp } from '@firebase/firestore';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import { auth, db } from '../../config/firebaseConfig';

export default function T16_ConfirmarSolicitacao({ navigation, route }) {
  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  const doacao = route?.params?.doacao || {};

  const [quantidade, setQuantidade] = useState('1');
  const [observacao, setObservacao] = useState('');
  const [enviando, setEnviando] = useState(false);

  const incrementar = () => {
    const valorAtual = parseInt(quantidade) || 1;
    setQuantidade(String(Math.min(99, valorAtual + 1)));
  };

  const decrementar = () => {
    const valorAtual = parseInt(quantidade) || 1;
    setQuantidade(String(Math.max(1, valorAtual - 1)));
  };

  const handleSolicitar = async () => {
    const user = auth.currentUser;

    if (!user) {
      Alert.alert('Erro', 'Você precisa estar logado para fazer uma solicitação.');
      return;
    }

    const qtd = parseInt(quantidade);

    if (!qtd || qtd <= 0) {
      Alert.alert('Erro', 'Digite uma quantidade válida.');
      return;
    }

    const imagemDaDoacao =
      doacao.imagem ||
      doacao.image ||
      doacao.img ||
      doacao.foto ||
      doacao.fotoUrl ||
      doacao.imagemUrl ||
      doacao.urlImagem ||
      '';

    setEnviando(true);

    try {
      await addDoc(collection(db, 'pedidos'), {
        idDoacao: doacao.id || '',
        idDoador: doacao.doadorID || doacao.idDoador || doacao.doadorId || '',
        idReceptor: user.uid,

        tituloDoacao: doacao.titulo || doacao.nome || 'Doação',
        nomeDoador: doacao.doador || doacao.nomeDoador || 'Doador',
        categoria: doacao.categoria || '',
        imgDoacao: imagemDaDoacao,

        quantidadePedida: qtd,
        observacao: observacao,

        status: 'Pendente',
        dataCriacao: serverTimestamp()
      });

      Alert.alert('Sucesso', 'Sua solicitação foi enviada ao doador.');
      navigation.navigate('MeusPedidos');
    } catch (error) {
      console.log('Erro ao salvar solicitação:', error);
      Alert.alert('Erro', 'Não foi possível salvar a solicitação no Firebase.');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor={theme.headerBackground} />

      <View style={[styles.header, { height: 70, justifyContent: 'center' }]}>
        <View
          style={[
            styles.headerTop,
            {
              justifyContent: 'space-between',
              width: '100%',
              paddingHorizontal: 10
            }
          ]}
        >
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={26} color={theme.headerTextInverse} />
          </TouchableOpacity>

          <Text style={[styles.headerTitulo, { fontSize: 22 }]}>
            Confirmar Pedido
          </Text>

          <View style={{ width: 26 }} />
        </View>
      </View>

      <ScrollView style={styles.conteudo} contentContainerStyle={styles.scrollContent}>
        <View style={styles.cardSolicitacao}>
          <Text style={[styles.infoLabel, { marginBottom: 10 }]}>
            Quantas unidades você precisa?
          </Text>

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 15 }}>
            <TouchableOpacity
              onPress={decrementar}
              disabled={enviando}
              style={[
                styles.infoIcone,
                { backgroundColor: theme.mode === 'dark' ? '#333' : '#EEE' }
              ]}
            >
              <Text style={{ fontSize: 20, color: theme.textPrimary }}>-</Text>
            </TouchableOpacity>

            <TextInput
              style={[
                styles.inputPequeno,
                {
                  borderColor: theme.secondary,
                  color: theme.textPrimary
                }
              ]}
              value={quantidade}
              onChangeText={setQuantidade}
              keyboardType="numeric"
              maxLength={2}
              editable={!enviando}
            />

            <TouchableOpacity
              onPress={incrementar}
              disabled={enviando}
              style={[
                styles.infoIcone,
                { backgroundColor: theme.mode === 'dark' ? '#333' : '#EEE' }
              ]}
            >
              <Text style={{ fontSize: 20, color: theme.textPrimary }}>+</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.cardSolicitacao}>
          <Text style={[styles.infoLabel, { marginBottom: 10 }]}>
            Observação (Opcional)
          </Text>

          <TextInput
            style={[
              styles.inputGrande,
              {
                borderColor: theme.secondary,
                color: theme.textPrimary
              }
            ]}
            placeholder="Ex: Chego em 10 minutos..."
            placeholderTextColor={theme.textMuted}
            multiline
            numberOfLines={3}
            value={observacao}
            onChangeText={setObservacao}
            textAlignVertical="top"
            editable={!enviando}
          />
        </View>

        <TouchableOpacity
          style={[
            styles.botaoAceitar,
            {
              backgroundColor: theme.secondary,
              paddingVertical: 16,
              borderRadius: 14,
              opacity: enviando ? 0.6 : 1
            }
          ]}
          onPress={handleSolicitar}
          disabled={enviando}
        >
          {enviando ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.botaoAceitarTexto}>
              Confirmar Solicitação
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}