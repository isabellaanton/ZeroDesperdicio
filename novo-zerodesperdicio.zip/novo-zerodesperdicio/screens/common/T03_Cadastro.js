import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
  ActivityIndicator
} from 'react-native';

import { createUserWithEmailAndPassword } from '@firebase/auth';
import { doc, setDoc } from '@firebase/firestore';

import { auth, db } from '../../config/firebaseConfig';
import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';

export default function T03_Cadastro({ navigation }) {
  const [tipo, setTipo] = useState('doador');
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [carregando, setCarregando] = useState(false);

  const { theme, isDarkMode } = useTheme();
  const styles = getGlobalStyles(theme);

  const handleCadastro = async () => {
    if (!nome || !email || !telefone || !senha || !confirmarSenha) {
      Alert.alert('Campos incompletos', 'Preencha todos os campos.');
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert('Senhas diferentes', 'A senha e a confirmação não conferem.');
      return;
    }

    if (senha.length < 6) {
      Alert.alert('Senha fraca', 'A senha precisa ter no mínimo 6 caracteres.');
      return;
    }

    setCarregando(true);

    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        senha
      );

      const user = userCredential.user;

      await setDoc(doc(db, 'usuarios', user.uid), {
        uid: user.uid,
        nome: nome,
        email: email,
        telefone: telefone,
        tipo: tipo,
        sobre: '',
        criadoEm: new Date()
      });

      Alert.alert('Sucesso', 'Conta criada com sucesso!');

      if (tipo === 'doador') {
        navigation.navigate('HomeDoador');
      } else {
        navigation.navigate('HomeReceptor');
      }
    } catch (error) {
      console.log('Erro no cadastro:', error);

      if (error.code === 'auth/email-already-in-use') {
        Alert.alert('E-mail já cadastrado', 'Este e-mail já está em uso.');
      } else if (error.code === 'auth/invalid-email') {
        Alert.alert('E-mail inválido', 'Digite um e-mail válido.');
      } else if (error.code === 'auth/weak-password') {
        Alert.alert('Senha fraca', 'A senha precisa ter no mínimo 6 caracteres.');
      } else if (error.code === 'auth/network-request-failed') {
        Alert.alert('Sem conexão', 'Verifique sua internet.');
      } else {
        Alert.alert('Erro', 'Não foi possível criar sua conta.');
      }
    } finally {
      setCarregando(false);
    }
  };

  return (
    <ScrollView style={styles.safeArea}>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={theme.background}
      />

      <View style={[styles.container, { paddingTop: 50 }]}>
        <Text style={styles.title}>Criar conta</Text>
        <Text style={styles.subtitle}>Você é:</Text>

        <View style={styles.tipoContainer}>
          <TouchableOpacity
            style={[
              styles.tipoBtn,
              tipo === 'doador' && styles.tipoSelecionado
            ]}
            onPress={() => setTipo('doador')}
            activeOpacity={0.8}
            disabled={carregando}
          >
            <Text style={{ fontSize: 30 }}>🏢</Text>
            <Text style={{ color: theme.primary, fontWeight: 'bold' }}>
              Doador
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.tipoBtn,
              tipo === 'receptor' && styles.tipoSelecionado
            ]}
            onPress={() => setTipo('receptor')}
            activeOpacity={0.8}
            disabled={carregando}
          >
            <Text style={{ fontSize: 30 }}>🤝</Text>
            <Text style={{ color: theme.primary, fontWeight: 'bold' }}>
              Receptor
            </Text>
          </TouchableOpacity>
        </View>

        <TextInput
          style={styles.input}
          placeholder="Nome completo"
          placeholderTextColor={theme.textMuted}
          value={nome}
          onChangeText={setNome}
          editable={!carregando}
        />

        <TextInput
          style={styles.input}
          placeholder="Digite seu email"
          placeholderTextColor={theme.textMuted}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          editable={!carregando}
        />

        <TextInput
          style={styles.input}
          placeholder="Digite seu telefone"
          placeholderTextColor={theme.textMuted}
          value={telefone}
          onChangeText={setTelefone}
          keyboardType="phone-pad"
          editable={!carregando}
        />

        <TextInput
          style={styles.input}
          placeholder="Digite sua senha"
          placeholderTextColor={theme.textMuted}
          value={senha}
          onChangeText={setSenha}
          secureTextEntry
          editable={!carregando}
        />

        <TextInput
          style={styles.input}
          placeholder="Confirme sua senha"
          placeholderTextColor={theme.textMuted}
          value={confirmarSenha}
          onChangeText={setConfirmarSenha}
          secureTextEntry
          editable={!carregando}
        />

        <TouchableOpacity
          style={styles.botao_entrar}
          onPress={handleCadastro}
          activeOpacity={0.8}
          disabled={carregando}
        >
          {carregando ? (
            <ActivityIndicator color={theme.buttonTextInverse || '#FFF'} />
          ) : (
            <Text style={styles.texto_botao_entrar}>Cadastrar</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}