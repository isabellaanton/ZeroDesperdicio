import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StatusBar,
  ActivityIndicator
} from 'react-native';

import { signInWithEmailAndPassword } from '@firebase/auth';
import { doc, getDoc } from '@firebase/firestore';

import { auth, db } from '../../config/firebaseConfig';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';

export default function T02_Login({ navigation }) {
  const { theme, isDarkMode } = useTheme();
  const styles = getGlobalStyles(theme);

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [carregando, setCarregando] = useState(false);

  const checarTipoENavegar = async (uid) => {
    try {
      const docRef = doc(db, 'usuarios', uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const dadosUsuario = docSnap.data();

        if (dadosUsuario.tipo === 'doador') {
          navigation.navigate('HomeDoador');
        } else if (dadosUsuario.tipo === 'receptor') {
          navigation.navigate('HomeReceptor');
        } else {
          Alert.alert('Erro', 'Tipo de usuário não identificado.');
        }
      } else {
        Alert.alert(
          'Usuário sem cadastro',
          'Não encontramos seus dados no banco.'
        );
      }
    } catch (error) {
      console.log('Erro ao buscar usuário:', error);
      Alert.alert('Erro', 'Não foi possível buscar o usuário.');
    }
  };

  const handleEmailLogin = async () => {
    if (!email || !senha) {
      Alert.alert('Campos obrigatórios', 'Preencha o e-mail e a senha.');
      return;
    }

    setCarregando(true);

    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        senha
      );

      const user = userCredential.user;
      await checarTipoENavegar(user.uid);
    } catch (error) {
      console.log('Erro no login:', error);

      if (
        error.code === 'auth/user-not-found' ||
        error.code === 'auth/wrong-password' ||
        error.code === 'auth/invalid-credential'
      ) {
        Alert.alert('Acesso negado', 'E-mail ou senha incorretos.');
      } else if (error.code === 'auth/invalid-email') {
        Alert.alert('E-mail inválido', 'Digite um e-mail válido.');
      } else if (error.code === 'auth/network-request-failed') {
        Alert.alert('Sem conexão', 'Verifique sua internet.');
      } else {
        Alert.alert('Erro no login', 'Não foi possível acessar sua conta.');
      }
    } finally {
      setCarregando(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={theme.background}
      />

      <Text style={styles.texto_bem_vindo}>Bem-vindo de volta</Text>
      <Text style={styles.texto_acesso_conta}>Acesse sua conta</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        placeholderTextColor={theme.textMuted}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        editable={!carregando}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        placeholderTextColor={theme.textMuted}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
        editable={!carregando}
      />

      <TouchableOpacity
        onPress={() => navigation.navigate('RecuperarSenha')}
        disabled={carregando}
      >
        <Text
          style={{
            color: theme.secondary,
            textAlign: 'right',
            marginTop: 10,
            marginRight: 15
          }}
        >
          Esqueci minha senha
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botao_entrar}
        onPress={handleEmailLogin}
        disabled={carregando}
      >
        {carregando ? (
          <ActivityIndicator color={theme.buttonTextInverse || '#FFF'} />
        ) : (
          <Text style={styles.texto_botao_entrar}>Entrar</Text>
        )}
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.navigate('Cadastro')}
        style={{ marginTop: 30 }}
        disabled={carregando}
      >
        <Text style={{ textAlign: 'center', color: theme.textSecondary }}>
          Não tem conta?{' '}
          <Text style={{ color: theme.primary, fontWeight: 'bold' }}>
            Cadastre-se
          </Text>
        </Text>
      </TouchableOpacity>
    </View>
  );
}