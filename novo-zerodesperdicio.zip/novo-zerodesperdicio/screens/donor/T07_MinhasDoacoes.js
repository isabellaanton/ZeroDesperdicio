import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Image,
  Alert,
  ActivityIndicator
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  deleteDoc
} from '@firebase/firestore';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import FooterDoador from './FooterDoador';
import { auth, db } from '../../config/firebaseConfig';

export default function T07_MinhasDoacoes({ navigation }) {
  const [filtroAtivo, setFiltroAtivo] = useState('Todos');
  const [doacoes, setDoacoes] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  useEffect(() => {
    const user = auth.currentUser;

    if (!user) {
      setCarregando(false);
      return;
    }

    const q = query(
      collection(db, 'doacoes'),
      where('idDoador', '==', user.uid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const lista = [];

        snapshot.forEach((documento) => {
          lista.push({
            id: documento.id,
            ...documento.data()
          });
        });

        setDoacoes(lista);
        setCarregando(false);
      },
      (error) => {
        console.log('Erro ao carregar doações:', error);
        setCarregando(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const excluirDoacao = (id) => {
    Alert.alert(
      'Excluir Doação',
      'Tem certeza que deseja remover este item?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'doacoes', id));
              Alert.alert('Sucesso', 'Doação excluída.');
            } catch (error) {
              console.log('Erro ao excluir doação:', error);
              Alert.alert('Erro', 'Não foi possível excluir a doação.');
            }
          }
        }
      ]
    );
  };

  const filtradas = doacoes.filter((item) => {
    if (filtroAtivo === 'Todos') return true;

    const status = String(item.status || '').toLowerCase();

    if (filtroAtivo === 'Pendentes') {
      return status === 'pendente' || status === 'disponível' || status === 'disponivel';
    }

    if (filtroAtivo === 'Concluídos') {
      return status === 'concluído' || status === 'concluido' || status === 'finalizado';
    }

    return true;
  });

  const imagemPadrao =
    'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=250&auto=format&fit=crop';

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />

      <View
        style={[
          styles.header,
          {
            height: 80,
            paddingHorizontal: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between'
          }
        ]}
      >
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons
            name="arrow-back"
            size={24}
            color={theme.headerTextInverse}
          />
        </TouchableOpacity>

        <Text style={[styles.headerTitulo, { fontSize: 20 }]}>
          Minhas Doações
        </Text>

        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        style={styles.conteudoHomeDoador}
        contentContainerStyle={{ paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ flexDirection: 'row', padding: 15, gap: 10 }}>
          {['Todos', 'Pendentes', 'Concluídos'].map((f) => (
            <TouchableOpacity
              key={f}
              onPress={() => setFiltroAtivo(f)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 20,
                backgroundColor:
                  filtroAtivo === f
                    ? theme.primary
                    : theme.mode === 'dark'
                    ? '#333'
                    : '#f0f0f0',
                borderWidth: 1,
                borderColor: filtroAtivo === f ? theme.primary : '#ddd'
              }}
            >
              <Text
                style={{
                  color: filtroAtivo === f ? '#fff' : theme.textPrimary,
                  fontWeight: filtroAtivo === f ? 'bold' : 'normal',
                  fontSize: 13
                }}
              >
                {f}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text
          style={{
            marginHorizontal: 15,
            marginBottom: 10,
            fontSize: 12,
            color: theme.textMuted,
            fontWeight: 'bold'
          }}
        >
          {filtradas.length} ITENS ENCONTRADOS
        </Text>

        {carregando ? (
          <View style={{ alignItems: 'center', marginTop: 50 }}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={{ color: theme.textMuted, marginTop: 10 }}>
              Carregando doações...
            </Text>
          </View>
        ) : filtradas.length === 0 ? (
          <View style={{ alignItems: 'center', marginTop: 50 }}>
            <Ionicons name="file-tray-outline" size={60} color={theme.textMuted} />
            <Text style={{ color: theme.textMuted, marginTop: 10 }}>
              Nenhuma doação encontrada.
            </Text>
          </View>
        ) : (
          filtradas.map((item) => {
            const status = item.status || 'Disponível';
            const statusBaixo = status.toLowerCase();

            const isPendente =
              statusBaixo === 'pendente' ||
              statusBaixo === 'disponível' ||
              statusBaixo === 'disponivel';

            const imagem = item.img || item.imagem || imagemPadrao;

            return (
              <View
                key={item.id}
                style={{
                  backgroundColor:
                    theme.cardBackground ||
                    (theme.mode === 'dark' ? '#1e1e1e' : '#fff'),
                  marginHorizontal: 15,
                  marginBottom: 12,
                  borderRadius: 15,
                  flexDirection: 'row',
                  padding: 12,
                  elevation: 3,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4
                }}
              >
                <Image
                  source={{ uri: imagem }}
                  style={{ width: 85, height: 85, borderRadius: 10 }}
                />

                <View
                  style={{
                    flex: 1,
                    marginLeft: 12,
                    justifyContent: 'space-between'
                  }}
                >
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start'
                    }}
                  >
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontWeight: 'bold',
                          fontSize: 16,
                          color: theme.textPrimary
                        }}
                        numberOfLines={1}
                      >
                        {item.titulo || 'Doação'}
                      </Text>

                      <Text
                        style={{
                          color: theme.textSecondary,
                          fontSize: 12,
                          marginTop: 2
                        }}
                      >
                        {item.descricao ||
                          `${item.quantidade || ''} ${item.unidade || ''}`}
                      </Text>
                    </View>

                    <TouchableOpacity
                      onPress={() => excluirDoacao(item.id)}
                      style={{ padding: 4 }}
                    >
                      <Ionicons name="trash-outline" size={20} color="#ff4444" />
                    </TouchableOpacity>
                  </View>

                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginTop: 10
                    }}
                  >
                    <View
                      style={{
                        backgroundColor: isPendente ? '#fff3cd' : '#d4edda',
                        paddingHorizontal: 8,
                        paddingVertical: 2,
                        borderRadius: 5
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 10,
                          fontWeight: 'bold',
                          color: isPendente ? '#856404' : '#155724',
                          textTransform: 'uppercase'
                        }}
                      >
                        {status}
                      </Text>
                    </View>

                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate('DetalheDoacaoDoador', {
                          doacaoId: item.id,
                          titulo: item.titulo,
                          descricao:
                            item.descricao ||
                            `${item.quantidade || ''} ${item.unidade || ''}`,
                          img: imagem
                        })
                      }
                      style={{ flexDirection: 'row', alignItems: 'center' }}
                    >
                      <Text
                        style={{
                          color: theme.primary,
                          fontWeight: 'bold',
                          fontSize: 13
                        }}
                      >
                        Ver mais
                      </Text>
                      <Ionicons
                        name="chevron-forward"
                        size={14}
                        color={theme.primary}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>

      <FooterDoador navigation={navigation} abaAtual="Doacoes" />
    </SafeAreaView>
  );
}