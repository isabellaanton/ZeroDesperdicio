import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Image,
  Alert,
  ActivityIndicator
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';

import { collection, addDoc, serverTimestamp } from '@firebase/firestore';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import { auth, db } from '../../config/firebaseConfig';

export default function T06_CadastrarDoacao({ navigation }) {
  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  const [categoria, setCategoria] = useState('Padaria');
  const [quantidade, setQuantidade] = useState('1');
  const [unidade, setUnidade] = useState('Unid');
  const [data, setData] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [foto, setFoto] = useState(null);
  const [salvando, setSalvando] = useState(false);

  const categorias = [
    'Padaria',
    'Hortifruti',
    'Proteínas',
    'Cesta Básica',
    'Marmitas',
    'Laticínios',
    'Bebidas',
    'Outros'
  ];

  const unidades = ['Unid', 'Kg', 'Gramas', 'Litros', 'Caixas', 'Pacotes'];
  const quantidades = Array.from({ length: 50 }, (_, i) => (i + 1).toString());

  const tirarFoto = async () => {
    const permissao = await ImagePicker.requestCameraPermissionsAsync();

    if (!permissao.granted) {
      Alert.alert('Permissão necessária', 'Permita o uso da câmera para tirar foto.');
      return;
    }

    const resultado = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.7
    });

    if (!resultado.canceled) {
      setFoto(resultado.assets[0].uri);
    }
  };

  const salvarDoacao = async () => {
    const user = auth.currentUser;

    if (!user) {
      Alert.alert('Erro', 'Você precisa estar logado para publicar uma doação.');
      return;
    }

    setSalvando(true);

    try {
      const imagemPadrao =
        'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=250&auto=format&fit=crop';

      await addDoc(collection(db, 'doacoes'), {
        idDoador: user.uid,
        doadorID: user.uid,

        titulo: categoria,
        categoria: categoria,
        quantidade: Number(quantidade),
        unidade: unidade,

        descricao: `${quantidade} ${unidade} • Expira em ${data.toLocaleDateString('pt-BR')}`,
        validade: data.toLocaleDateString('pt-BR'),

        imagem: foto || imagemPadrao,
        img: foto || imagemPadrao,

        status: 'Disponível',
        solicitacoes: 0,

        criadoEm: serverTimestamp()
      });

      Alert.alert('Sucesso', 'Doação publicada com sucesso!');
      navigation.navigate('MinhasDoacoes');
    } catch (error) {
      console.log('Erro ao salvar doação:', error);
      Alert.alert('Erro', 'Não foi possível publicar a doação no Firebase.');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header_cadastro}>
        <TouchableOpacity onPress={() => navigation.goBack()} disabled={salvando}>
          <Ionicons
            name="arrow-back"
            size={24}
            color={theme.headerTextInverse}
          />
        </TouchableOpacity>

        <Text style={styles.tituloCadastro}>Nova Doação</Text>
      </View>

      <ScrollView style={styles.conteudo} contentContainerStyle={{ padding: 20 }}>
        <Text style={styles.labelCadastro}>Categoria do Alimento</Text>

        <View
          style={{
            backgroundColor: theme.mode === 'dark' ? '#333' : '#f0f0f0',
            borderRadius: 10,
            marginBottom: 15
          }}
        >
          <Picker
            selectedValue={categoria}
            onValueChange={(itemValue) => setCategoria(itemValue)}
            style={{ color: theme.textPrimary }}
            dropdownIconColor={theme.primary}
          >
            {categorias.map((c) => (
              <Picker.Item key={c} label={c} value={c} />
            ))}
          </Picker>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <View style={{ flex: 0.45 }}>
            <Text style={styles.labelCadastro}>Qtd.</Text>

            <View
              style={{
                backgroundColor: theme.mode === 'dark' ? '#333' : '#f0f0f0',
                borderRadius: 10
              }}
            >
              <Picker
                selectedValue={quantidade}
                onValueChange={(v) => setQuantidade(v)}
                style={{ color: theme.textPrimary }}
              >
                {quantidades.map((q) => (
                  <Picker.Item key={q} label={q} value={q} />
                ))}
              </Picker>
            </View>
          </View>

          <View style={{ flex: 0.45 }}>
            <Text style={styles.labelCadastro}>Unidade</Text>

            <View
              style={{
                backgroundColor: theme.mode === 'dark' ? '#333' : '#f0f0f0',
                borderRadius: 10
              }}
            >
              <Picker
                selectedValue={unidade}
                onValueChange={(v) => setUnidade(v)}
                style={{ color: theme.textPrimary }}
              >
                {unidades.map((u) => (
                  <Picker.Item key={u} label={u} value={u} />
                ))}
              </Picker>
            </View>
          </View>
        </View>

        <Text style={[styles.labelCadastro, { marginTop: 15 }]}>
          Disponível até
        </Text>

        <TouchableOpacity
          style={[
            styles.inputCadastro,
            {
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between'
            }
          ]}
          onPress={() => setShowPicker(true)}
          disabled={salvando}
        >
          <Text style={{ color: theme.textPrimary }}>
            {data.toLocaleDateString('pt-BR')}
          </Text>
          <Ionicons name="calendar" size={20} color={theme.primary} />
        </TouchableOpacity>

        {showPicker && (
          <DateTimePicker
            value={data}
            mode="date"
            onChange={(e, d) => {
              setShowPicker(false);
              if (d) setData(d);
            }}
          />
        )}

        <Text style={[styles.labelCadastro, { marginTop: 15 }]}>
          Foto do Alimento
        </Text>

        <TouchableOpacity
          style={{
            height: 150,
            backgroundColor: theme.mode === 'dark' ? '#333' : '#eee',
            borderRadius: 10,
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 20,
            borderWidth: 1,
            borderStyle: 'dashed',
            borderColor: theme.textMuted
          }}
          onPress={tirarFoto}
          disabled={salvando}
        >
          {foto ? (
            <Image
              source={{ uri: foto }}
              style={{ width: '100%', height: '100%', borderRadius: 10 }}
            />
          ) : (
            <>
              <Ionicons name="camera" size={40} color={theme.textMuted} />
              <Text style={{ color: theme.textMuted }}>
                Toque para tirar foto
              </Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.botaoNovaDoacao,
            {
              backgroundColor: theme.primary,
              opacity: salvando ? 0.6 : 1
            }
          ]}
          onPress={salvarDoacao}
          disabled={salvando}
        >
          {salvando ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.botaoNovaDoacaoTexto}>
              Publicar Doação
            </Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}