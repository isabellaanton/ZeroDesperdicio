import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Image,
  Alert,
  ActivityIndicator
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  updateDoc
} from '@firebase/firestore';

import { getGlobalStyles } from '../../Styles';
import { useTheme } from '../../ThemeContext';
import FooterDoador from './FooterDoador';
import { db } from '../../config/firebaseConfig';

export default function T08_DetalheDoacaoDoador({ route, navigation }) {
  const { theme } = useTheme();
  const styles = getGlobalStyles(theme);

  const {
    doacaoId,
    titulo,
    descricao,
    img
  } = route.params || {};

  const [pedidos, setPedidos] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    if (!doacaoId) {
      setCarregando(false);
      return;
    }

    const q = query(
      collection(db, 'pedidos'),
      where('idDoacao', '==', doacaoId)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const lista = [];

        snapshot.forEach((documento) => {
          lista.push({
            id: documento.id,
            ...documento.data()
          });
        });

        setPedidos(lista);
        setCarregando(false);
      },
      (error) => {
        console.log('Erro ao buscar pedidos:', error);
        setCarregando(false);
      }
    );

    return () => unsubscribe();
  }, [doacaoId]);

  const atualizarStatusPedido = async (idPedido, novoStatus) => {
    try {
      await updateDoc(doc(db, 'pedidos', idPedido), {
        status: novoStatus
      });

      Alert.alert('Sucesso', `Solicitação ${novoStatus.toLowerCase()} com sucesso!`);
    } catch (error) {
      console.log('Erro ao atualizar pedido:', error);
      Alert.alert('Erro', 'Não foi possível atualizar a solicitação.');
    }
  };

  const corStatus = (status) => {
    if (status === 'Aceito' || status === 'Concluído') {
      return {
        fundo: '#E8F5E9',
        texto: '#006B14'
      };
    }

    if (status === 'Recusado') {
      return {
        fundo: '#FDECEA',
        texto: '#B00020'
      };
    }

    return {
      fundo: '#FFF3CD',
      texto: '#856404'
    };
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar
        barStyle="light-content"
        backgroundColor={theme.headerBackground}
      />

      <View style={[styles.header, { height: 70, justifyContent: 'center' }]}>
        <View
          style={[
            styles.headerTop,
            {
              justifyContent: 'space-between',
              width: '100%',
              paddingHorizontal: 15
            }
          ]}
        >
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons
              name="arrow-back"
              size={26}
              color={theme.headerTextInverse}
            />
          </TouchableOpacity>

          <Text style={[styles.headerTitulo, { fontSize: 20 }]}>
            Gerenciar Doação
          </Text>

          <View style={{ width: 26 }} />
        </View>
      </View>

      <ScrollView
        style={styles.conteudoHomeDoador}
        contentContainerStyle={{ paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            padding: 20,
            backgroundColor: theme.cardBackground,
            marginBottom: 10,
            flexDirection: 'row',
            alignItems: 'center'
          }}
        >
          <Image
            source={{
              uri:
                img ||
                'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=250&auto=format&fit=crop'
            }}
            style={{
              width: 60,
              height: 60,
              borderRadius: 10,
              marginRight: 15
            }}
          />

          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: 'bold',
                color: theme.textPrimary
              }}
            >
              {titulo || 'Doação'}
            </Text>

            <Text style={{ color: theme.textSecondary }}>
              {descricao || 'Sem descrição'}
            </Text>
          </View>
        </View>

        <Text style={[styles.secaoTitulo, { marginLeft: 20, marginTop: 10 }]}>
          SOLICITAÇÕES RECEBIDAS
        </Text>

        {carregando ? (
          <View style={{ marginTop: 40, alignItems: 'center' }}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={{ color: theme.textMuted, marginTop: 10 }}>
              Carregando solicitações...
            </Text>
          </View>
        ) : pedidos.length === 0 ? (
          <View style={{ alignItems: 'center', marginTop: 50 }}>
            <Ionicons
              name="document-text-outline"
              size={60}
              color={theme.textMuted}
            />
            <Text style={{ color: theme.textMuted, marginTop: 10 }}>
              Nenhuma solicitação recebida.
            </Text>
          </View>
        ) : (
          pedidos.map((pedido) => {
            const cores = corStatus(pedido.status);

            return (
              <View
                key={pedido.id}
                style={[
                  styles.cardSolicitacao,
                  {
                    marginHorizontal: 20,
                    padding: 15,
                    borderRadius: 15,
                    elevation: 3,
                    marginBottom: 15
                  }
                ]}
              >
                <View style={styles.cardHeader}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.nomeOng, { fontSize: 18 }]}>
                      {pedido.nomeReceptor || 'Receptor'}
                    </Text>

                    <Text style={{ fontSize: 12, color: theme.textMuted }}>
                      Quantidade solicitada: {pedido.quantidadePedida || 1}
                    </Text>
                  </View>

                  <View
                    style={[
                      styles.badgePendente,
                      {
                        backgroundColor: cores.fundo,
                        borderColor: cores.texto,
                        borderWidth: 1
                      }
                    ]}
                  >
                    <Text
                      style={[
                        styles.badgePendenteTexto,
                        {
                          color: cores.texto,
                          fontWeight: 'bold'
                        }
                      ]}
                    >
                      {pedido.status || 'Pendente'}
                    </Text>
                  </View>
                </View>

                <Text style={[styles.descricaoSolicitacao, { marginVertical: 10 }]}>
                  {pedido.observacao
                    ? `"${pedido.observacao}"`
                    : 'Sem observação.'}
                </Text>

                {pedido.status === 'Pendente' && (
                  <View style={{ flexDirection: 'row', gap: 10, marginTop: 5 }}>
                    <TouchableOpacity
                      style={[
                        styles.botaoAceitar,
                        {
                          flex: 1,
                          backgroundColor: '#28a745',
                          flexDirection: 'row',
                          justifyContent: 'center',
                          alignItems: 'center'
                        }
                      ]}
                      onPress={() => atualizarStatusPedido(pedido.id, 'Aceito')}
                    >
                      <Ionicons name="checkmark-circle" size={18} color="#fff" />
                      <Text style={[styles.botaoAceitarTexto, { marginLeft: 5 }]}>
                        Aceitar
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[
                        styles.botaoRecusar,
                        {
                          flex: 1,
                          borderColor: '#dc3545',
                          borderWidth: 1,
                          backgroundColor: 'transparent',
                          flexDirection: 'row',
                          justifyContent: 'center',
                          alignItems: 'center'
                        }
                      ]}
                      onPress={() => atualizarStatusPedido(pedido.id, 'Recusado')}
                    >
                      <Ionicons name="close-circle" size={18} color="#dc3545" />
                      <Text
                        style={[
                          styles.botaoRecusarTexto,
                          {
                            color: '#dc3545',
                            marginLeft: 5
                          }
                        ]}
                      >
                        Recusar
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            );
          })
        )}
      </ScrollView>

      <FooterDoador navigation={navigation} abaAtual="Doacoes" />
    </SafeAreaView>
  );
}