import React from 'react';
import { View, Text, Image, ScrollView, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from './style';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color="white" />
        <Text style={styles.headerTitle}>Histórico</Text>
        <Ionicons name="menu" size={24} color="white" />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.statsContainer}>
          <StatItem valor="23" label="recebidas" />
          <StatItem valor="4.8" label="avaliação" />
          <StatItem valor="52kg" label="recebidos" />
        </View>

        <PedidoCard 
          titulo="Marmita Caseira" 
          imagem="https://images.unsplash.com/photo-1547592166-23ac45744acd?w=200" 
        />
        <PedidoCard 
          titulo="Pães Frescos" 
          imagem="https://images.unsplash.com/photo-1509440159596-0249088772ff?w=200" 
        />
      </ScrollView>

      <View style={styles.tabBar}>
        <TabItem icon="home-outline" label="Início" />
        <TabItem icon="map-outline" label="Mapa" />
        <TabItem icon="bag-handle" label="Pedidos" />
        <TabItem icon="chatbubble-outline" label="Chat" />
      </View>
    </SafeAreaView>
  );
}

const StatItem = ({ valor, label }) => (
  <View style={styles.statBox}>
    <Text style={styles.statNumber}>{valor}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const PedidoCard = ({ titulo, imagem }) => (
  <View style={styles.card}>
    <Image source={{ uri: imagem }} style={styles.cardImage} />
    <View style={styles.cardInfo}>
      <Text style={styles.cardTitle}>{titulo}</Text>
      <View style={styles.statusButton}>
        <Text style={styles.statusText}>Concluído</Text>
      </View>
    </View>
  </View>
);

const TabItem = ({ icon, label }) => (
  <View style={styles.tabItem}>
    <Ionicons name={icon} size={24} color="black" />
    <Text style={styles.tabText}>{label}</Text>
  </View>
);