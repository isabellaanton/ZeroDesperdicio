import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDE3B7',
  },
  header: {
    backgroundColor: '#00701A',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    marginTop: 30,
  },
  headerTitle: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
  },
  content: {
    padding: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#F9D1A5',
    borderWidth: 1,
    borderColor: '#D35400',
    borderRadius: 10,
    paddingVertical: 15,
    marginBottom: 25,
  },
  statBox: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  statLabel: {
    fontSize: 12,
    color: '#333',
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#F9D1A5',
    borderWidth: 1,
    borderColor: '#D35400',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    alignItems: 'center',
  },
  cardImage: {
    width: 100,
    height: 80,
    borderRadius: 8,
  },
  cardInfo: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'center',
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 10,
  },
  statusButton: {
    backgroundColor: '#1CB800',
    borderRadius: 15,
    paddingVertical: 5,
    alignItems: 'center',
  },
  statusText: {
    color: 'white',
    fontWeight: 'bold',
  },
  tabBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#FDE3B7',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#CCC',
  },
  tabItem: {
    alignItems: 'center',
  },
  tabText: {
    fontSize: 10,
  },
});